import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { VEGLBudget, VEGLBudgetLine } from "./views";

@graphInfo({graphType: "VelixoConnectedAppConfig.VEGLBudgetWritebackController", primaryView: "Budget", })
export class VE300310 extends PXScreen {

   	@viewInfo({containerName: "Budget"})
	Budget = createSingle(VEGLBudget);
	Details = createCollection(VEGLBudgetLine);
}