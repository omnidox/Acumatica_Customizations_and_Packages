import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";


// Views

export class VEGLBudget extends PXView  {

	BranchID : PXFieldState;
	LedgerID : PXFieldState;
	FinYear : PXFieldState;
	Release : PXFieldState;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class VEGLBudgetLine extends PXView  {

	@columnConfig({hideViewLink: true})	AccountID : PXFieldState;
	@columnConfig({hideViewLink: true})	SubID : PXFieldState;
	Amount : PXFieldState;
	Period1 : PXFieldState;
	Period2 : PXFieldState;
	Period3 : PXFieldState;
	Period4 : PXFieldState;
	Period5 : PXFieldState;
	Period6 : PXFieldState;
	Period7 : PXFieldState;
	Period8 : PXFieldState;
	Period9 : PXFieldState;
	Period10 : PXFieldState;
	Period11 : PXFieldState;
	Period12 : PXFieldState;
	Period13 : PXFieldState;
	Period14 : PXFieldState;
	Period15 : PXFieldState;
	Period16 : PXFieldState;
	Period17 : PXFieldState;
	Period18 : PXFieldState;
	Period19 : PXFieldState;
	Period20 : PXFieldState;
	Period21 : PXFieldState;
	Period22 : PXFieldState;
	Period23 : PXFieldState;
	Period24 : PXFieldState;
	Period25 : PXFieldState;
	Period26 : PXFieldState;
	Period27 : PXFieldState;
	Period28 : PXFieldState;
	Period29 : PXFieldState;
	Period30 : PXFieldState;
	Period31 : PXFieldState;
	Period32 : PXFieldState;
	Period33 : PXFieldState;
	Period34 : PXFieldState;
	Period35 : PXFieldState;
	Period36 : PXFieldState;
	Period37 : PXFieldState;
	Period38 : PXFieldState;
	Period39 : PXFieldState;
	Period40 : PXFieldState;
	Period41 : PXFieldState;
	Period42 : PXFieldState;
	Period43 : PXFieldState;
	Period44 : PXFieldState;
	Period45 : PXFieldState;
	Period46 : PXFieldState;
	Period47 : PXFieldState;
	Period48 : PXFieldState;
	Period49 : PXFieldState;
	Period50 : PXFieldState;
	Period51 : PXFieldState;
	Period52 : PXFieldState;
	Period53 : PXFieldState;
	Period54 : PXFieldState;
	Period55 : PXFieldState;
	Period56 : PXFieldState;
	Period57 : PXFieldState;
	Period58 : PXFieldState;
	Period59 : PXFieldState;
	Period60 : PXFieldState;
	Period61 : PXFieldState;
	Period62 : PXFieldState;
	Period63 : PXFieldState;
	Period64 : PXFieldState;
	Period65 : PXFieldState;
	Period66 : PXFieldState;
	Period67 : PXFieldState;
	Period68 : PXFieldState;
	Period69 : PXFieldState;
	Period70 : PXFieldState;
	Period71 : PXFieldState;
	Period72 : PXFieldState;
	Period73 : PXFieldState;
	Period74 : PXFieldState;
	Period75 : PXFieldState;
	Period76 : PXFieldState;
	Period77 : PXFieldState;
	Period78 : PXFieldState;
	Period79 : PXFieldState;
	Period80 : PXFieldState;
	Period81 : PXFieldState;
	Period82 : PXFieldState;
	Period83 : PXFieldState;
	Period84 : PXFieldState;
	Period85 : PXFieldState;
	Period86 : PXFieldState;
	Period87 : PXFieldState;
	Period88 : PXFieldState;
	Period89 : PXFieldState;
	Period90 : PXFieldState;
	Period91 : PXFieldState;
	Period92 : PXFieldState;
	Period93 : PXFieldState;
	Period94 : PXFieldState;
	Period95 : PXFieldState;
	Period96 : PXFieldState;
	Period97 : PXFieldState;
	Period98 : PXFieldState;
	Period99 : PXFieldState;
}