import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";


// Views

export class VECostProjection extends PXView  {

	CostProjectionClassID : PXFieldState;
	ProjectID : PXFieldState;
	Revision : PXFieldState;
	RevisionDate : PXFieldState;
	Description : PXFieldState;
}

@gridConfig({
	initNewRow: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class VECostProjectionLine extends PXView  {

	ProjectID : PXFieldState;
	Revision : PXFieldState;
	AccountGroupID : PXFieldState;
	CostTaskID : PXFieldState;
	CostCodeID : PXFieldState;
	Description : PXFieldState;
	InventoryItemID : PXFieldState;
	ProjectedCompleted : PXFieldState;
	ProjectedCostAtCompletion : PXFieldState;
	ProjectedCostToComplete : PXFieldState;
	ProjectedQuantityAtCompletion : PXFieldState;
	ProjectedQuantityToComplete : PXFieldState;
	ProjectedVarianceCost : PXFieldState;
	ProjectedVarianceQuantity : PXFieldState;
}