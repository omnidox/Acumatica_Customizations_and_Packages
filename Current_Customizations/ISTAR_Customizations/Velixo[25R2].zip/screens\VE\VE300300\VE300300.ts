import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { PMForecast, PMForecastDetail } from "./views";

@graphInfo({graphType: "VelixoConnectedAppConfig.VEProjectBudgetForecastWritebackController", primaryView: "Revisions", })
export class VE300300 extends PXScreen {

   	@viewInfo({containerName: "Forecast Revision"})
	Revisions = createSingle(PMForecast);
	Details = createCollection(PMForecastDetail);
}