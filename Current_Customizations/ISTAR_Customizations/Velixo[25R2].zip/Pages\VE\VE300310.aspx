<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
	ValidateRequest="false" CodeFile="VE300310.aspx.cs" Inherits="Page_VE300310"
	Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<px:PXDataSource ID="ds" Width="100%" runat="server" PrimaryView="Budget" TypeName="VelixoConnectedAppConfig.VEGLBudgetWritebackController"  Visible="True">
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="Process" CommitChanges="True" />
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="Budget" Caption="Budget">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" ColumnWidth="L" />
			<px:PXSelector ID="edBranch" runat="server" DataField="BranchID" />
			<px:PXSelector ID="edLedger" runat="server" DataField="LedgerID" />
			<px:PXTextEdit ID="edFinYear" runat="server" DataField="FinYear" />
			<px:PXCheckBox ID="edRelease" runat="server" DataField="Release" />
        </Template>
    </px:PXFormView>    
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
	<px:PXGrid ID="grid" runat="server" Height="350px" Width="100%" SkinID="Details">
		<Levels>
			<px:PXGridLevel DataMember="Details">
				<RowTemplate>
					<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M" />
					<px:PXSegmentMask ID="edAccount" runat="server" DataField="AccountID" />
					<px:PXSegmentMask ID="edSubaccount" runat="server" DataField="SubID" />
					<px:PXTextEdit ID="edAmount" runat="server" DataField="Amount" />
					<px:PXTextEdit ID="edPeriod1" runat="server" DataField="Period1" />
					<px:PXTextEdit ID="edPeriod2" runat="server" DataField="Period2" />
					<px:PXTextEdit ID="edPeriod3" runat="server" DataField="Period3" />
					<px:PXTextEdit ID="edPeriod4" runat="server" DataField="Period4" />
					<px:PXTextEdit ID="edPeriod5" runat="server" DataField="Period5" />
					<px:PXTextEdit ID="edPeriod6" runat="server" DataField="Period6" />
					<px:PXTextEdit ID="edPeriod7" runat="server" DataField="Period7" />
					<px:PXTextEdit ID="edPeriod8" runat="server" DataField="Period8" />
					<px:PXTextEdit ID="edPeriod9" runat="server" DataField="Period9" />
					<px:PXTextEdit ID="edPeriod10" runat="server" DataField="Period10" />
					<px:PXTextEdit ID="edPeriod11" runat="server" DataField="Period11" />
					<px:PXTextEdit ID="edPeriod12" runat="server" DataField="Period12" />
					<px:PXTextEdit ID="edPeriod13" runat="server" DataField="Period13" />
					<px:PXTextEdit ID="edPeriod14" runat="server" DataField="Period14" />
					<px:PXTextEdit ID="edPeriod15" runat="server" DataField="Period15" />
					<px:PXTextEdit ID="edPeriod16" runat="server" DataField="Period16" />
					<px:PXTextEdit ID="edPeriod17" runat="server" DataField="Period17" />
					<px:PXTextEdit ID="edPeriod18" runat="server" DataField="Period18" />
					<px:PXTextEdit ID="edPeriod19" runat="server" DataField="Period19" />
					<px:PXTextEdit ID="edPeriod20" runat="server" DataField="Period20" />
					<px:PXTextEdit ID="edPeriod21" runat="server" DataField="Period21" />
					<px:PXTextEdit ID="edPeriod22" runat="server" DataField="Period22" />
					<px:PXTextEdit ID="edPeriod23" runat="server" DataField="Period23" />
					<px:PXTextEdit ID="edPeriod24" runat="server" DataField="Period24" />
					<px:PXTextEdit ID="edPeriod25" runat="server" DataField="Period25" />
					<px:PXTextEdit ID="edPeriod26" runat="server" DataField="Period26" />
					<px:PXTextEdit ID="edPeriod27" runat="server" DataField="Period27" />
					<px:PXTextEdit ID="edPeriod28" runat="server" DataField="Period28" />
					<px:PXTextEdit ID="edPeriod29" runat="server" DataField="Period29" />
					<px:PXTextEdit ID="edPeriod30" runat="server" DataField="Period30" />
					<px:PXTextEdit ID="edPeriod31" runat="server" DataField="Period31" />
					<px:PXTextEdit ID="edPeriod32" runat="server" DataField="Period32" />
					<px:PXTextEdit ID="edPeriod33" runat="server" DataField="Period33" />
					<px:PXTextEdit ID="edPeriod34" runat="server" DataField="Period34" />
					<px:PXTextEdit ID="edPeriod35" runat="server" DataField="Period35" />
					<px:PXTextEdit ID="edPeriod36" runat="server" DataField="Period36" />
					<px:PXTextEdit ID="edPeriod37" runat="server" DataField="Period37" />
					<px:PXTextEdit ID="edPeriod38" runat="server" DataField="Period38" />
					<px:PXTextEdit ID="edPeriod39" runat="server" DataField="Period39" />
					<px:PXTextEdit ID="edPeriod40" runat="server" DataField="Period40" />
					<px:PXTextEdit ID="edPeriod41" runat="server" DataField="Period41" />
					<px:PXTextEdit ID="edPeriod42" runat="server" DataField="Period42" />
					<px:PXTextEdit ID="edPeriod43" runat="server" DataField="Period43" />
					<px:PXTextEdit ID="edPeriod44" runat="server" DataField="Period44" />
					<px:PXTextEdit ID="edPeriod45" runat="server" DataField="Period45" />
					<px:PXTextEdit ID="edPeriod46" runat="server" DataField="Period46" />
					<px:PXTextEdit ID="edPeriod47" runat="server" DataField="Period47" />
					<px:PXTextEdit ID="edPeriod48" runat="server" DataField="Period48" />
					<px:PXTextEdit ID="edPeriod49" runat="server" DataField="Period49" />
					<px:PXTextEdit ID="edPeriod50" runat="server" DataField="Period50" />
					<px:PXTextEdit ID="edPeriod51" runat="server" DataField="Period51" />
					<px:PXTextEdit ID="edPeriod52" runat="server" DataField="Period52" />
					<px:PXTextEdit ID="edPeriod53" runat="server" DataField="Period53" />
					<px:PXTextEdit ID="edPeriod54" runat="server" DataField="Period54" />
					<px:PXTextEdit ID="edPeriod55" runat="server" DataField="Period55" />
					<px:PXTextEdit ID="edPeriod56" runat="server" DataField="Period56" />
					<px:PXTextEdit ID="edPeriod57" runat="server" DataField="Period57" />
					<px:PXTextEdit ID="edPeriod58" runat="server" DataField="Period58" />
					<px:PXTextEdit ID="edPeriod59" runat="server" DataField="Period59" />
					<px:PXTextEdit ID="edPeriod60" runat="server" DataField="Period60" />
					<px:PXTextEdit ID="edPeriod61" runat="server" DataField="Period61" />
					<px:PXTextEdit ID="edPeriod62" runat="server" DataField="Period62" />
					<px:PXTextEdit ID="edPeriod63" runat="server" DataField="Period63" />
					<px:PXTextEdit ID="edPeriod64" runat="server" DataField="Period64" />
					<px:PXTextEdit ID="edPeriod65" runat="server" DataField="Period65" />
					<px:PXTextEdit ID="edPeriod66" runat="server" DataField="Period66" />
					<px:PXTextEdit ID="edPeriod67" runat="server" DataField="Period67" />
					<px:PXTextEdit ID="edPeriod68" runat="server" DataField="Period68" />
					<px:PXTextEdit ID="edPeriod69" runat="server" DataField="Period69" />
					<px:PXTextEdit ID="edPeriod70" runat="server" DataField="Period70" />
					<px:PXTextEdit ID="edPeriod71" runat="server" DataField="Period71" />
					<px:PXTextEdit ID="edPeriod72" runat="server" DataField="Period72" />
					<px:PXTextEdit ID="edPeriod73" runat="server" DataField="Period73" />
					<px:PXTextEdit ID="edPeriod74" runat="server" DataField="Period74" />
					<px:PXTextEdit ID="edPeriod75" runat="server" DataField="Period75" />
					<px:PXTextEdit ID="edPeriod76" runat="server" DataField="Period76" />
					<px:PXTextEdit ID="edPeriod77" runat="server" DataField="Period77" />
					<px:PXTextEdit ID="edPeriod78" runat="server" DataField="Period78" />
					<px:PXTextEdit ID="edPeriod79" runat="server" DataField="Period79" />
					<px:PXTextEdit ID="edPeriod80" runat="server" DataField="Period80" />
					<px:PXTextEdit ID="edPeriod81" runat="server" DataField="Period81" />
					<px:PXTextEdit ID="edPeriod82" runat="server" DataField="Period82" />
					<px:PXTextEdit ID="edPeriod83" runat="server" DataField="Period83" />
					<px:PXTextEdit ID="edPeriod84" runat="server" DataField="Period84" />
					<px:PXTextEdit ID="edPeriod85" runat="server" DataField="Period85" />
					<px:PXTextEdit ID="edPeriod86" runat="server" DataField="Period86" />
					<px:PXTextEdit ID="edPeriod87" runat="server" DataField="Period87" />
					<px:PXTextEdit ID="edPeriod88" runat="server" DataField="Period88" />
					<px:PXTextEdit ID="edPeriod89" runat="server" DataField="Period89" />
					<px:PXTextEdit ID="edPeriod90" runat="server" DataField="Period90" />
					<px:PXTextEdit ID="edPeriod91" runat="server" DataField="Period91" />
					<px:PXTextEdit ID="edPeriod92" runat="server" DataField="Period92" />
					<px:PXTextEdit ID="edPeriod93" runat="server" DataField="Period93" />
					<px:PXTextEdit ID="edPeriod94" runat="server" DataField="Period94" />
					<px:PXTextEdit ID="edPeriod95" runat="server" DataField="Period95" />
					<px:PXTextEdit ID="edPeriod96" runat="server" DataField="Period96" />
					<px:PXTextEdit ID="edPeriod97" runat="server" DataField="Period97" />
					<px:PXTextEdit ID="edPeriod98" runat="server" DataField="Period98" />
					<px:PXTextEdit ID="edPeriod99" runat="server" DataField="Period99" />
				</RowTemplate>
				<Columns>
					<px:PXGridColumn DataField="AccountID"/>
					<px:PXGridColumn DataField="SubID"/>
					<px:PXGridColumn DataField="Amount"/>
					<px:PXGridColumn DataField="Period1"/>
					<px:PXGridColumn DataField="Period2"/>
					<px:PXGridColumn DataField="Period3"/>
					<px:PXGridColumn DataField="Period4"/>
					<px:PXGridColumn DataField="Period5"/>
					<px:PXGridColumn DataField="Period6"/>
					<px:PXGridColumn DataField="Period7"/>
					<px:PXGridColumn DataField="Period8"/>
					<px:PXGridColumn DataField="Period9"/>
					<px:PXGridColumn DataField="Period10"/>
					<px:PXGridColumn DataField="Period11"/>
					<px:PXGridColumn DataField="Period12"/>
					<px:PXGridColumn DataField="Period13"/>
					<px:PXGridColumn DataField="Period14"/>
					<px:PXGridColumn DataField="Period15"/>
					<px:PXGridColumn DataField="Period16"/>
					<px:PXGridColumn DataField="Period17"/>
					<px:PXGridColumn DataField="Period18"/>
					<px:PXGridColumn DataField="Period19"/>
					<px:PXGridColumn DataField="Period20"/>
					<px:PXGridColumn DataField="Period11"/>
					<px:PXGridColumn DataField="Period12"/>
					<px:PXGridColumn DataField="Period13"/>
					<px:PXGridColumn DataField="Period14"/>
					<px:PXGridColumn DataField="Period15"/>
					<px:PXGridColumn DataField="Period16"/>
					<px:PXGridColumn DataField="Period17"/>
					<px:PXGridColumn DataField="Period18"/>
					<px:PXGridColumn DataField="Period19"/>
					<px:PXGridColumn DataField="Period20"/>
					<px:PXGridColumn DataField="Period11"/>
					<px:PXGridColumn DataField="Period12"/>
					<px:PXGridColumn DataField="Period13"/>
					<px:PXGridColumn DataField="Period14"/>
					<px:PXGridColumn DataField="Period15"/>
					<px:PXGridColumn DataField="Period16"/>
					<px:PXGridColumn DataField="Period17"/>
					<px:PXGridColumn DataField="Period18"/>
					<px:PXGridColumn DataField="Period19"/>
					<px:PXGridColumn DataField="Period20"/>
					<px:PXGridColumn DataField="Period21"/>
					<px:PXGridColumn DataField="Period22"/>
					<px:PXGridColumn DataField="Period23"/>
					<px:PXGridColumn DataField="Period24"/>
					<px:PXGridColumn DataField="Period25"/>
					<px:PXGridColumn DataField="Period26"/>
					<px:PXGridColumn DataField="Period27"/>
					<px:PXGridColumn DataField="Period28"/>
					<px:PXGridColumn DataField="Period29"/>
					<px:PXGridColumn DataField="Period30"/>
					<px:PXGridColumn DataField="Period31"/>
					<px:PXGridColumn DataField="Period32"/>
					<px:PXGridColumn DataField="Period33"/>
					<px:PXGridColumn DataField="Period34"/>
					<px:PXGridColumn DataField="Period35"/>
					<px:PXGridColumn DataField="Period36"/>
					<px:PXGridColumn DataField="Period37"/>
					<px:PXGridColumn DataField="Period38"/>
					<px:PXGridColumn DataField="Period39"/>
					<px:PXGridColumn DataField="Period40"/>
					<px:PXGridColumn DataField="Period41"/>
					<px:PXGridColumn DataField="Period42"/>
					<px:PXGridColumn DataField="Period43"/>
					<px:PXGridColumn DataField="Period44"/>
					<px:PXGridColumn DataField="Period45"/>
					<px:PXGridColumn DataField="Period46"/>
					<px:PXGridColumn DataField="Period47"/>
					<px:PXGridColumn DataField="Period48"/>
					<px:PXGridColumn DataField="Period49"/>
					<px:PXGridColumn DataField="Period50"/>
					<px:PXGridColumn DataField="Period51"/>
					<px:PXGridColumn DataField="Period52"/>
					<px:PXGridColumn DataField="Period53"/>
					<px:PXGridColumn DataField="Period54"/>
					<px:PXGridColumn DataField="Period55"/>
					<px:PXGridColumn DataField="Period56"/>
					<px:PXGridColumn DataField="Period57"/>
					<px:PXGridColumn DataField="Period58"/>
					<px:PXGridColumn DataField="Period59"/>
					<px:PXGridColumn DataField="Period60"/>
					<px:PXGridColumn DataField="Period61"/>
					<px:PXGridColumn DataField="Period62"/>
					<px:PXGridColumn DataField="Period63"/>
					<px:PXGridColumn DataField="Period64"/>
					<px:PXGridColumn DataField="Period65"/>
					<px:PXGridColumn DataField="Period66"/>
					<px:PXGridColumn DataField="Period67"/>
					<px:PXGridColumn DataField="Period68"/>
					<px:PXGridColumn DataField="Period69"/>
					<px:PXGridColumn DataField="Period70"/>
					<px:PXGridColumn DataField="Period71"/>
					<px:PXGridColumn DataField="Period72"/>
					<px:PXGridColumn DataField="Period73"/>
					<px:PXGridColumn DataField="Period74"/>
					<px:PXGridColumn DataField="Period75"/>
					<px:PXGridColumn DataField="Period76"/>
					<px:PXGridColumn DataField="Period77"/>
					<px:PXGridColumn DataField="Period78"/>
					<px:PXGridColumn DataField="Period79"/>
					<px:PXGridColumn DataField="Period80"/>
					<px:PXGridColumn DataField="Period81"/>
					<px:PXGridColumn DataField="Period82"/>
					<px:PXGridColumn DataField="Period83"/>
					<px:PXGridColumn DataField="Period84"/>
					<px:PXGridColumn DataField="Period85"/>
					<px:PXGridColumn DataField="Period86"/>
					<px:PXGridColumn DataField="Period87"/>
					<px:PXGridColumn DataField="Period88"/>
					<px:PXGridColumn DataField="Period89"/>
					<px:PXGridColumn DataField="Period90"/>
					<px:PXGridColumn DataField="Period91"/>
					<px:PXGridColumn DataField="Period92"/>
					<px:PXGridColumn DataField="Period93"/>
					<px:PXGridColumn DataField="Period94"/>
					<px:PXGridColumn DataField="Period95"/>
					<px:PXGridColumn DataField="Period96"/>
					<px:PXGridColumn DataField="Period97"/>
					<px:PXGridColumn DataField="Period98"/>
					<px:PXGridColumn DataField="Period99"/>
				</Columns>
				<Styles>
					<RowForm Height="250px">
					</RowForm>
				</Styles>
			</px:PXGridLevel>
		</Levels>
		<Layout FormViewHeight="250px" />
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
		<Mode AllowFormEdit="True" AllowUpload="True" />
		<CallbackCommands>
			<Save PostData="Content" />
		</CallbackCommands>
	</px:PXGrid>
</asp:Content>
