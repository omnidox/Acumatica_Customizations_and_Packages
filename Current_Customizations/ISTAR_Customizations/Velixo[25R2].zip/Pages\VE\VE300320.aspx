<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
	ValidateRequest="false" CodeFile="VE300320.aspx.cs" Inherits="Page_VE300320"
	Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<px:PXDataSource ID="ds" Width="100%" runat="server" PrimaryView="CostProjection" TypeName="VelixoConnectedAppConfig.VECostProjectionWritebackController"  Visible="True">
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="Process" CommitChanges="True" />
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="CostProjection" Caption="Cost Projection">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" ColumnWidth="L" />
			<px:PXTextEdit ID="edCostProjectionClassId" runat="server" DataField="CostProjectionClassID" />
			<px:PXTextEdit ID="edProjectId" runat="server" DataField="ProjectID" />
			<px:PXTextEdit ID="edRevision" runat="server" DataField="Revision" />
			<px:PXTextEdit ID="edRevisionDate" runat="server" DataField="RevisionDate" />
			<px:PXTextEdit ID="edDescription" runat="server" DataField="Description" />
        </Template>
    </px:PXFormView>    
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
	<px:PXGrid ID="grid" runat="server" Height="350px" Width="100%" SkinID="Details">
		<Levels>
			<px:PXGridLevel DataMember="Details">
				<RowTemplate>
					<px:PXLayoutRule runat="server" StartColumn="False" LabelsWidth="SM" ControlSize="M" ></px:PXLayoutRule>
					<px:PXTextEdit ID="edProjectID" runat="server" DataField="ProjectID" />
					<px:PXTextEdit ID="edRevision" runat="server" DataField="Revision" />
					<px:PXSelector ID="edAccountGroupId" runat="server" DataField="AccountGroupID" />
					<px:PXTextEdit ID="edCostTaskId" runat="server" DataField="CostTaskID" />
					<px:PXSelector ID="edCostCodeId" runat="server" DataField="CostCodeID" />
					<px:PXTextEdit ID="edDescription" runat="server" DataField="Description" />
					<px:PXSelector ID="edInventoryItemId" runat="server" DataField="InventoryItemID" />
					<px:PXTextEdit ID="edProjectedCompleted" runat="server" DataField="ProjectedCompleted" />
					<px:PXTextEdit ID="edProjectedCostAtCompletion" runat="server" DataField="ProjectedCostAtCompletion" />
					<px:PXTextEdit ID="edProjectedCostToComplete" runat="server" DataField="ProjectedCostToComplete" />
					<px:PXTextEdit ID="edProjectedQuantityAtCompletion" runat="server" DataField="ProjectedQuantityAtCompletion" />
					<px:PXTextEdit ID="edProjectedQuantityToComplete" runat="server" DataField="ProjectedQuantityToComplete" />
					<px:PXTextEdit ID="edProjectedVarianceCost" runat="server" DataField="ProjectedVarianceCost" />
					<px:PXTextEdit ID="edProjectedVarianceQuantity" runat="server" DataField="ProjectedVarianceQuantity" />
				</RowTemplate>
				<Columns>
					<px:PXGridColumn DataField="ProjectID"/>
					<px:PXGridColumn DataField="Revision" />
					<px:PXGridColumn DataField="AccountGroupID" />
					<px:PXGridColumn DataField="CostTaskID" />
					<px:PXGridColumn DataField="CostCodeID" />
					<px:PXGridColumn DataField="Description" />
					<px:PXGridColumn DataField="InventoryItemID" />
					<px:PXGridColumn DataField="ProjectedCompleted" />
					<px:PXGridColumn DataField="ProjectedCostAtCompletion" />
					<px:PXGridColumn DataField="ProjectedCostToComplete" />
					<px:PXGridColumn DataField="ProjectedQuantityAtCompletion" />
					<px:PXGridColumn DataField="ProjectedQuantityToComplete" />
					<px:PXGridColumn DataField="ProjectedVarianceCost" />
					<px:PXGridColumn DataField="ProjectedVarianceQuantity" />
				</Columns>
				<Styles>
					<RowForm Height="250px">
					</RowForm>
				</Styles>
			</px:PXGridLevel>
		</Levels>
		<Layout FormViewHeight="250px" />
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
		<Mode AllowFormEdit="True" AllowUpload="True" InitNewRow="True"/>
		<CallbackCommands>
			<Save PostData="Content" />
		</CallbackCommands>
	</px:PXGrid>
</asp:Content>
