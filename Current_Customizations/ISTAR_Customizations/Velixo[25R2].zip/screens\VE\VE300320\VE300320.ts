import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { VECostProjection, VECostProjectionLine } from "./views";

@graphInfo({graphType: "VelixoConnectedAppConfig.VECostProjectionWritebackController", primaryView: "CostProjection", })
export class VE300320 extends PXScreen {

   	@viewInfo({containerName: "Cost Projection"})
	CostProjection = createSingle(VECostProjection);
	Details = createCollection(VECostProjectionLine);
}