<%@ Page Language="C#" MasterPageFile="~/MasterPages/ClearWorkspace.master" CodeFile="VelixoLauncher.aspx.cs" AutoEventWireup="true" Inherits="Page_Show" Title="Velixo Launcher" %>
<%@ MasterType VirtualPath="~/MasterPages/ClearWorkspace.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<a id="download" href="placeholder.example.org" download></a>
	<script type="text/javascript">
    function goBack() {
	/*
	* The code below intends to resolve an issue when in Safari download did not start.
	* We don't know exactly the root cause, but it seems that Safari has a bug or 
	* some side-effect of "early go away from the page".
	*/
        setTimeout(() => {
            if (window.opener == null)
        {
            window.history.back();
        }
        else
        {
            window.close();
        }            
        }, 200);
    }

    (function () {
        const queryString = (window.location.search || '').substr(1);
        const params = {};

        if (queryString.length) {
            const keyValuePairs = queryString.split('&');

            for (const keyValuePair of keyValuePairs) {
                const [key, value] = keyValuePair.split('=');

                if (!(key?.length > 0)) {
                    continue;
                }

                params[key] = value;
            }
        }

        if (params.action === 'new') {
            const resultingUrlSearchParams = new URLSearchParams();
            resultingUrlSearchParams.set("action", "download");

            const resultingUrlString = `VelixoLauncher.aspx?${resultingUrlSearchParams.toString()}`;

            console.log(`Navigating to ${resultingUrlString}`);

            // Needs to be done through a button because it has a 'download' attribute.
            // -
            const downloadButton = document.getElementById('download');
            downloadButton.href = resultingUrlString;
            downloadButton.click();

            goBack();
        } else if (params.action === 'navigate') {          
            const uri = decodeURIComponent(params.uri);
            
            console.log(`Navigating to ${uri} (new window)`);

            window.open(uri, '_blank');

            goBack();
        }
    })();
    </script>
</asp:Content>
