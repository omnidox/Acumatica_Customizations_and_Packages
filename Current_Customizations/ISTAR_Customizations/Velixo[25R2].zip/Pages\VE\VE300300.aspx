<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="VE300300.aspx.cs" Inherits="Page_VE300300" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="VelixoConnectedAppConfig.VEProjectBudgetForecastWritebackController" PrimaryView="Revisions"
        BorderStyle="NotSet">
        <CallbackCommands>
            <px:PXDSCallbackCommand CommitChanges="True" Name="Save" />
            <px:PXDSCallbackCommand CommitChanges="True" Name="UpdateBudgetBalanceForCurrentLine" Visible="false" DependOnGrid="grid" />
            <px:PXDSCallbackCommand CommitChanges="True" Name="UpdateBudgetBalanceForAllLines" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="Revisions" Caption="Forecast Revision">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" ColumnWidth="L" />
             <px:PXSegmentMask ID="edProjectID" runat="server" DataField="ProjectID" DataSourceID="ds" AutoRefresh="True" AllowEdit="True"  NullText="<SELECT>">
            </px:PXSegmentMask>
            <px:PXSelector ID="edRevisionID" runat="server" DataField="RevisionID" AutoRefresh="true"/>
            <px:PXLayoutRule runat="server" ColumnSpan="2" />
			<px:PXTextEdit ID="edDescription" runat="server" DataField="Description" CommitChanges="True" />
        </Template>
    </px:PXFormView>    
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Height="150px" Style="z-index: 100" Width="100%" ActionsPosition="Top"
        SkinID="Details" AllowPaging="True" SyncPosition="true" AdjustPageSize="None" PageSize="200">
        <Levels>
            <px:PXGridLevel DataMember="Details" Visible="True">
                <RowTemplate>
                    <px:PXSegmentMask ID="edProjectTaskID" runat="server" DataField="ProjectTaskID" AutoRefresh="True" />
                    <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" AutoRefresh="True" />
                    <px:PXSelector ID="edAccountGroupID" runat="server" DataField="AccountGroupID" AutoRefresh="True" />
                    <px:PXSegmentMask ID="edCostCodeCost" runat="server" DataField="CostCodeID" AutoRefresh="True" AllowAddNew="true" />
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="ProjectTaskID" CommitChanges="true" />
                    <px:PXGridColumn DataField="AccountGroupID" CommitChanges="true" />
                    <px:PXGridColumn DataField="InventoryID" CommitChanges="true" />
                    <px:PXGridColumn DataField="CostCodeID" CommitChanges="true" />
                    <px:PXGridColumn DataField="PeriodID" CommitChanges="true" />
                    <px:PXGridColumn DataField="Description" />
                    <px:PXGridColumn DataField="Qty" />
                    <px:PXGridColumn DataField="CuryAmount" />
                    <px:PXGridColumn DataField="RevisedQty" />
                    <px:PXGridColumn DataField="CuryRevisedAmount" />
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <ActionBar>
            <CustomItems>
                <px:PXToolBarButton Key="cmdUpdateBudgetBalanceForCurrentLine">
                    <AutoCallBack Command="UpdateBudgetBalanceForCurrentLine" Target="ds" />
                </px:PXToolBarButton>
            </CustomItems>
        </ActionBar>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
        <Mode AllowUpload="true" AllowAddNew="true" AllowDelete="true" />
    </px:PXGrid>
</asp:Content>