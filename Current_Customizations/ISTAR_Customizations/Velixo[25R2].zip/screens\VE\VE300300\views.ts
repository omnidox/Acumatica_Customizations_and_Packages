import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";


// Views

export class PMForecast extends PXView  {

	@controlConfig({allowEdit:true,nullText:"<SELECT>"})
	ProjectID : PXFieldState;
	RevisionID : PXFieldState;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
	UpdateBudgetBalanceForCurrentLine: {index: 0, config: {commandName: "UpdateBudgetBalanceForCurrentLine", text: "Update Budget From Current Line"}},
}
})
export class PMForecastDetail extends PXView  {

	UpdateBudgetBalanceForCurrentLine : PXActionState;
	@columnConfig({hideViewLink: true})	ProjectTaskID : PXFieldState<PXFieldOptions.CommitChanges>;
	AccountGroupID : PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true})	CostCodeID : PXFieldState<PXFieldOptions.CommitChanges>;
	PeriodID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState;
	Qty : PXFieldState;
	CuryAmount : PXFieldState;
	RevisedQty : PXFieldState;
	CuryRevisedAmount : PXFieldState;
}