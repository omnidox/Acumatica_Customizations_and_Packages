<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="PO303002.aspx.cs" Inherits="Page_PO303002" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="ASCISTARCustom.PO.ASCiStarVendorDutyMaint"
        PrimaryView="ASCiStarVendorDutyView"
        >
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="First" Visible="False" />
			<px:PXDSCallbackCommand Name="Previous" Visible="False" />
			<px:PXDSCallbackCommand Name="Next" Visible="False" />
			<px:PXDSCallbackCommand Name="Last" Visible="False" />
			<px:PXDSCallbackCommand Name="CopyPaste" Visible="False" />
			<px:PXDSCallbackCommand Name="Save" Visible="True" />
			<px:PXDSCallbackCommand Name="Cancel" Visible="True" />
			<px:PXDSCallbackCommand Name="Insert" Visible="False" />
			<px:PXDSCallbackCommand Name="Delete" Visible="False" /></CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid SyncPosition="True" KeepPosition="True" runat="server" ID="grid" Height="150px" SkinID="Primary" Width="100%" AllowAutoHide="false" DataSourceID="ds">
		<AutoSize Enabled="True" Container="Window" MinHeight="150" ></AutoSize>
		<Levels>
			<px:PXGridLevel DataMember="ASCiStarVendorDutyView">
								<RowTemplate>
				<px:PXSelector ID="test1" runat="server" DataField="Branch" AutoRefresh="True" CommitChanges="true" ></px:PXSelector>
				<px:PXSelector ID="test2" runat="server" DataField="UOM" AutoRefresh="True" CommitChanges="true" ></px:PXSelector>
			</RowTemplate>
				<Columns>
					<px:PXGridColumn DataField="Branch" Width="140" ></px:PXGridColumn>
					<px:PXGridColumn DataField="UOM" Width="72" ></px:PXGridColumn>
					<px:PXGridColumn DisplayFormat="##0.00" DataField="Freight" Width="100" ></px:PXGridColumn>
					<px:PXGridColumn DataField="EffectiveDate" Width="90" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
		<Mode AllowUpload="True" InitNewRow="True" ></Mode>
		<Mode AllowUpload="True" ></Mode>
	</px:PXGrid></asp:Content>
