<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="SP301090.aspx.cs" Inherits="Page_SP301090" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="SNPMFG.Prd.SPINKitSpecInq"
        PrimaryView="Filter">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" DataMember="Filter">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" Merge="True" LabelsWidth="XS" ControlSize="S" />
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" AutoRefresh="true" CommitChanges="true">
            </px:PXSelector>
            <px:PXLayoutRule runat="server" />
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Inquire" AllowPaging="True" AdjustPageSize="Auto">
        <Levels>
            <px:PXGridLevel DataMember="CompUsage">
                <Columns>
	<px:PXGridColumn DataField="OwnerKitCD" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="OwnerRevisionID" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="OwnerKitDescr" Width="280" ></px:PXGridColumn>
	<px:PXGridColumn DataField="ComponentQty" Width="100" />
	<px:PXGridColumn DataField="ComponentUOM" Width="72" ></px:PXGridColumn></Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>
</asp:Content>