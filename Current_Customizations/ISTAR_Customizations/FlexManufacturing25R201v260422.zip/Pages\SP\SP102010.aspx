<%@ Page Language="C#" MasterPageFile="~/MasterPages/TabView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SP102010.aspx.cs" Inherits="Page_SP102010" Title="Flex Manufacturing Configuration" %>
<%@ MasterType VirtualPath="~/MasterPages/TabView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="SNPMFG.Prd.SPWrkOrderMaint"   PrimaryView="WrkOrderSetup">
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXTab DataMember="WrkOrderSetup" ID="tab" runat="server" DataSourceID="ds" Height="150px" Style="z-index: 100" Width="100%" AllowAutoHide="false">
		<Items>
			<px:PXTabItem Text="Core Flex">
				<Template>
					<px:PXLayoutRule LabelsWidth="L" ControlSize="XL" runat="server" ID="CstPXLayoutRule1" StartRow="True" ></px:PXLayoutRule>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule2" StartGroup="True" GroupCaption="Reference Settings" ></px:PXLayoutRule>
					<px:PXSelector runat="server" ID="CstPXSelector4" DataField="WorkOrderNumberingID" ></px:PXSelector>
					<px:PXSelector runat="server" ID="CstPXSelector3" DataField="ProdPlanNumberingID" ></px:PXSelector>

					<px:PXLayoutRule GroupCaption="Labor  Settings" runat="server" ID="CstPXLayoutRule14" StartGroup="True" ></px:PXLayoutRule>
					<px:PXSelector runat="server" ID="CstPXSelector18" DataField="WoLaborUnit" ></px:PXSelector>
					<px:PXSelector runat="server" ID="CstPXSelector16" DataField="DefLaborCalendarID" ></px:PXSelector>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox15" DataField="AllowCalendarRestriction" ></px:PXCheckBox>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox19" DataField="ScheduleLaborTasks" ></px:PXCheckBox>
					<px:PXNumberEdit runat="server" ID="CstPXNumberEdit17" DataField="ProdDefaultHourlyCost" ></px:PXNumberEdit>
					
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule7" StartGroup="True" GroupCaption="Behaviors" ></px:PXLayoutRule>
					<px:PXSegmentMask runat="server" ID="CstPXSegmentMask29" DataField="DefManufLocationID" ></px:PXSegmentMask>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox6" DataField="ConsumeAvailableInv" ></px:PXCheckBox>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox9" DataField="IgnoreSpecQtyVariation" ></px:PXCheckBox>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox10" DataField="PlanningStatusIsAllocated" ></px:PXCheckBox>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox8" DataField="ErrorOnInsufficientLocationOnHand" ></px:PXCheckBox>
					<px:PXDropDown runat="server" ID="CstPXDropDown12" DataField="PurchaseFullfilmentPreference" ></px:PXDropDown>
					
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule6" StartGroup="True" GroupCaption="Options" ></px:PXLayoutRule>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox7" DataField="OptionEnhancedInventroyFeedBack" ></px:PXCheckBox>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox5" DataField="ReportWrkOrderPurchaseReceiptComplete" ></px:PXCheckBox>
				</Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Features" >
				<Template>
					<px:PXFormView runat="server" ID="FlXFormViewFeatures8" DataMember="FlexFeatureView" DataSourceID="ds" >
						<Template>
							<px:PXLayoutRule runat="server" ID="FLXCstPXLayoutRule9" StartColumn="True" ></px:PXLayoutRule>
							<px:PXCheckBox runat="server" ID="FLXCstPXCheckBox10" DataField="UsrFlexMan" ></px:PXCheckBox>
							<px:PXCheckBox runat="server" ID="FLXCstPXCheckBox11" DataField="UsrFlexManCLP" />
							<px:PXCheckBox runat="server" ID="FLXCstPXCheckBox12" DataField="UsrFlexManCRM" />
							<px:PXCheckBox runat="server" ID="FLXCstPXCheckBox13" DataField="UsrFlexManETO" />
							<px:PXCheckBox runat="server" ID="FLXCstPXCheckBox14" DataField="UsrFlexManWIP" />
							<px:PXCheckBox runat="server" ID="FLXCstPXCheckBox15" DataField="UsrFlexManZCI" />
						</Template></px:PXFormView>
				</Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Diagnostics / Tasks">
			
				<Template>
					<px:PXLayoutRule LabelsWidth="M" runat="server" ID="CstPXLayoutRule19" StartRow="True" ></px:PXLayoutRule>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule20" StartGroup="True" GroupCaption="Instance Details" ></px:PXLayoutRule>
								<px:PXTextEdit runat="server" ID="CstPXTextEdit4" DataField="AcumaticaVersion" ></px:PXTextEdit>
					<%-- <px:PXTextEdit runat="server" ID="CstPXTextEdit23" DataField="ProductVersion" ></px:PXTextEdit> --%>
					<%-- <px:PXTextEdit runat="server" ID="CstPXTextEdit22" DataField="ConnectedServer" ></px:PXTextEdit> --%>
					<%-- <px:PXTextEdit runat="server" ID="CstPXTextEdit21" DataField="ConnectedDB" ></px:PXTextEdit> --%>
								<px:PXLayoutRule runat="server" ID="CstPXLayoutRule3" StartGroup="True" GroupCaption="Tasks" ></px:PXLayoutRule>
								<px:PXCheckBox runat="server" ID="CstPXCheckBox28" DataField="UnRestrictKit" ></px:PXCheckBox>
								<%-- <px:PXCheckBox Enabled="False" runat="server" DataField="FlxFeaturesState" ID="FlxFeatureState" Text="Flx Features State" ></px:PXCheckBox> --%>
								<px:PXButton runat="server" ID="FlxDeleteOrphanKits" Text="Delete Orphaned Kit Assemblied" CommandSourceID="ds" CommandName="DeleteOrphanedKits" ></px:PXButton>
								<%-- <px:PXLayoutRule runat="server" ID="CstPXLayoutRule24" StartGroup="True" GroupCaption="Debug Settings" ></px:PXLayoutRule> --%>
								<%-- <px:PXCheckBox runat="server" ID="CstPXCheckBox25" DataField="Diagnostics" ></px:PXCheckBox> --%>
								<%-- <px:PXTextEdit runat="server" ID="CstPXTextEdit26" DataField="LoggingURLAndPort" ></px:PXTextEdit> --%>
								<%-- <px:PXSegmentMask runat="server" ID="CstPXSegmentMask27" DataField="MRPDumpInventoryID" ></px:PXSegmentMask>--%>
					</Template></px:PXTabItem></Items> 
		<AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
	</px:PXTab>
</asp:Content>