<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SP400030.aspx.cs" Inherits="Page_SP400030" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="SNPMFG.Prd.FlxSpecCompAvailEnq" 
        PrimaryView="Filter">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Style="z-index: 100" Width="100%">
        <Template>
            <px:PXLayoutRule ControlSize="L" LabelsWidth="XM" runat="server" ID="lmCstPXLayoutRule1" StartRow="True"></px:PXLayoutRule>
	<px:PXSelector runat="server" ID="CstPXSelector1" DataField="WrkOrdNbr" /></Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
		AllowPaging="True" AllowSearch="true" AdjustPageSize="Auto" DataSourceID="ds" SkinID="PrimaryInquire" SyncPosition="True">
        <Levels>
            <px:PXGridLevel DataMember="WrkOrderBOMs">
                <Columns>
                    <px:PXGridColumn DataField="BomDescr" Width="400" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="UOM" Width="72" ></px:PXGridColumn>
	<px:PXGridColumn DataField="BaseQtyRequired" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="Available" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="OnHand" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="Shortage" Width="100" />
	<px:PXGridColumn DataField="VendorLeadTime" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="VendorDesc" Width="180" ></px:PXGridColumn></Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXGrid>
</asp:Content>