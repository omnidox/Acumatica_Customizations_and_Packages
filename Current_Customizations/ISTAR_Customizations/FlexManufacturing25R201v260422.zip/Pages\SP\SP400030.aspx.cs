using System;
using System.Reflection;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Linq;


public partial class  Page_SP400030 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    private void RegisterStyle(string name, string backColor, string foreColor, bool bold)
    {
       
    }

    protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
	
    }
}