<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SP502013.aspx.cs"
    Inherits="Page_SP502013" Title="Prod Orders Processing" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<style type="text/css">
		.SettingTable table:not([class~=GridRowForm]) tbody tr td {
			white-space: pre !important;
		}

		#tooltip {
			white-space: pre-wrap !important;
		}
	</style>
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="SNPMFG.Prd.SPWrkOrderReleaseProcess" PrimaryView="Filter">
		<CallbackCommands>
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Style="z-index: 100" Width="100%">
		<Template>
			<px:PXLayoutRule ControlSize="L" LabelsWidth="XM" runat="server" ID="ASCCstPXLayoutRule2" StartRow="True"></px:PXLayoutRule>
			<px:PXDropDown CommitChanges="True" ID="edAction" runat="server" DataField="Action"></px:PXDropDown>
			<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="ASCCstPXSelector6" DataField="DeliveryDateStart"></px:PXDateTimeEdit>
			<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="ASCCstPXSelector7" DataField="DeliveryDateEnd"></px:PXDateTimeEdit>
			<px:PXSegmentMask CommitChanges="True" runat="server" DataField="SiteID" ID="edSiteID" ></px:PXSegmentMask>
			<px:PXLayoutRule runat="server" ID="ASCCstPXLayoutRule9" StartColumn="True"></px:PXLayoutRule>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="chkBxShowHold" DataField="ShowHold"></px:PXCheckBox>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="ckkBxShowBespokeOrdersOnly" DataField="ShowBespokeOrdersOnly"></px:PXCheckBox>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" />
			<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit2" DataField="ReDate" ></px:PXDateTimeEdit></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" StatusField="Availability" Height="150px" AllowAutoHide="False" TabIndex="6400" SyncPosition="True" BatchUpdate="true" ActionsPosition="Top" SkinID="PrimaryInquire" AllowPaging="True" AllowSearch="True" CssClass="SettingTable">
		<Levels>
			<px:PXGridLevel DataMember="WrkOrderList">
				<RowTemplate>
					<%-- Note:
                        In order to get the hyperlink to work in the columns, it is necessary to define them
                        like this in the RowTemplate section of the grid
                    --%>
					<px:PXSelector ID="edWrkOrdNbr" runat="server" DataField="WrkOrdNbr" Enabled="False" AllowEdit="True" />
					<%-- <px:PXSegmentMask CommitChanges="true" ID="edWrkOrdNbr" runat="server" DataField="WrkOrdNbr" AllowEdit="true" Enabled="false"></px:PXSegmentMask> --%>
					<px:PXSegmentMask CommitChanges="True" ID="edInventoryID" runat="server" DataField="InventoryID" AllowEdit="True" Enabled="false" />
					<px:PXSelector ID="edKitAssy" runat="server" DataField="KitREfNbr" Enabled="False" AllowEdit="True" />
				</RowTemplate>
				<Columns>
					<px:PXGridColumn AllowCheckAll="True" AllowMove="False" Type="CheckBox" DataField="Selected" Width="50" TextAlign="Center" AllowSort="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="WrkOrdNbr" Width="85px" LinkCommand="ViewDocument" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="Status" AllowUpdate="False" Width="75px"></px:PXGridColumn>
					<px:PXGridColumn DataField="DemandRefType" Width="80px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="DemandRef" Width="80px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="ParentWONbr" Width="100px" AllowUpdate="False"></px:PXGridColumn>
					<%--ParentWONbr is actually Breadcrumb --%>
					<px:PXGridColumn DataField="InventoryID" Width="100px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="Descr" Width="200px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="ProdPlannedDate" Width="100px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="PlannedQty" Width="70px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="UOM" TextAlign="Center" Width="65px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="PlannedLabor" Width="80px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="WoLaborUnit" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="CompDependencyLeadTime" Width="80px" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="Hold" TextAlign="Center" Width="70px" Type="CheckBox" AllowUpdate="False"></px:PXGridColumn>
					<px:PXGridColumn DataField="KitRefNbr" AllowUpdate="False" Width="85px"></px:PXGridColumn>
					<px:PXGridColumn DataField="KitStatus" AllowUpdate="False" Width="75px"></px:PXGridColumn>
				</Columns>
			</px:PXGridLevel>
		</Levels>
		<ActionBar DefaultAction="ViewOrder"></ActionBar>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
	</px:PXGrid>
	<actionbar>
		<ActionBar DefaultAction="viewDocument" />
	</actionbar>
</asp:Content>