using System;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Linq;

using System.Text;
using SNPMFG.Prd;

public partial class Page_SP302011 : PX.Web.UI.PXPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
		//RegisterStyle("FlxCellGreen", "GreenYellow", null, false, true);
		//RegisterStyle("RowYellow", "Yellow", null, false);
	}

	private void RegisterStyle(string name, string backColor, string foreColor, bool bold, bool important = false)
	{
		Style style = new Style();

		if (!string.IsNullOrEmpty(backColor)) style.BackColor = Color.FromName(backColor);
		//if (!string.IsNullOrEmpty(backColor)) style.BackColor = System.Drawing.ColorTranslator(backColor + " !important");
		if (!string.IsNullOrEmpty(foreColor)) style.ForeColor = Color.FromName(foreColor);
		style.Font.Bold = bold;
		this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
	}

	protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
	{

		SNPMFG.Prd.SPDAOrderEntry woGraph = this.ds.DataGraph as SNPMFG.Prd.SPDAOrderEntry;
		woGraph.GridRowStyling((PX.Web.UI.PXGrid)sender, ref e);

		//     if (this.ds.DataGraph.Implements<SNPMFG.Prd.IFlxRowCallBackToGraph>())
		//     {
		//         SNPMFG.Prd.IFlxRowCallBackToGraph cbg = this.ds.DataGraph as SNPMFG.Prd.IFlxRowCallBackToGraph;
		//         cbg.GridRowStyling(sender, e);
		//     }
		// }
	}
}