<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SPTM3030.aspx.cs" Inherits="Page_SPTM3030" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="SNPMFG.Prd.SPTMLaborScanEntry"
        PrimaryView="ScanHeader"
        >
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="ClockOn" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ClockOff" Visible="False" CommitChanges="true" />
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView FilesIndicator="False" DefaultControlID="edBarcode" ID="form" runat="server" DataSourceID="ds" DataMember="ScanHeader" Width="100%" Height="130px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXLayoutRule ControlSize="L" LabelsWidth="S" runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
			<px:PXTextEdit CommitChanges="True" runat="server" ID="edBarcode" DataField="Barcode" >
				<ClientEvents Initialize="Barcode_Initialize"></ClientEvents>
			</px:PXTextEdit>
			<px:PXSelector AllowEdit="True" runat="server" ID="CstPXSelector9" DataField="WorkOrderNbr" ></px:PXSelector>
			<px:PXSegmentMask AllowEdit="True" runat="server" ID="CstPXSegmentMask4" DataField="EmployeeID" ></px:PXSegmentMask>
			<px:PXSegmentMask AllowEdit="True" runat="server" ID="CstPXSegmentMask6" DataField="InventoryID" ></px:PXSegmentMask>
			<px:PXLayoutRule ColumnWidth="M" ControlSize="L" LabelsWidth="S" runat="server" ID="CstPXLayoutRule2" StartColumn="True" ></px:PXLayoutRule>
			<px:PXTextEdit DisableSpellcheck="True" SkinID="Label" Size="" Width="500px" Height="55px" TextAlign="Left" TextMode="MultiLine" runat="server" ID="CstPXTextEdit7" DataField="Message" ></px:PXTextEdit></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds" AllowAutoHide="false">
		<Items>
			<px:PXTabItem Text="Labor Tasks and Work Records">
				<Template>
					<px:PXSplitContainer runat="server" ID="sp1" SkinID="Horizontal" SplitterPosition="300">
						<AutoSize Enabled="True" Container="Window" />
						<Template1>
							<px:PXGrid OnRowDataBound="grid_RowDataBound" AutoAdjustColumns="True" SkinID="Inquire" Width="100%" DataSourceID="ds" SyncPosition="True" KeepPosition="True" runat="server" ID="ScanDetailsGrid" CaptionVisible="true" Caption="Prod Order Labor Tasks">
								<Levels>
									<px:PXGridLevel DataMember="ScanDetails" >
										<Columns>
											<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
											<px:PXGridColumn DataField="TranDesc" Width="280" ></px:PXGridColumn>
											<px:PXGridColumn DataField="QtyReqd" Width="100" ></px:PXGridColumn>
											<px:PXGridColumn DataField="UOM" Width="72" ></px:PXGridColumn>
											<px:PXGridColumn DataField="LabourConsumedExt" Width="100" ></px:PXGridColumn>
											<px:PXGridColumn DataField="ItemType" Width="70" ></px:PXGridColumn>
											<px:PXGridColumn DataField="InventoryID_description" Width="280" ></px:PXGridColumn>
										</Columns>
									</px:PXGridLevel>
								</Levels>
								<AutoSize Enabled="True" ></AutoSize>
							</px:PXGrid>
						</Template1>
						<Template2>
							<px:PXGrid ID="ScanDetailRecorsGrid" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" SkinID="Inquire" Caption="Work Record" CaptionVisible="true" SyncPosition="True" AutoAdjustColumns="True">
								<Levels>
									<px:PXGridLevel DataMember="ScanDetailRecors">
										<Columns>
											<px:PXGridColumn DataField="OperationStartTime_Date" Width="90" ></px:PXGridColumn>
											<px:PXGridColumn TimeMode="True" DataField="OperationStartTime_Time" Width="90" ></px:PXGridColumn>
											<px:PXGridColumn DataField="OperationStopTime_Date" Width="90" ></px:PXGridColumn>
											<px:PXGridColumn TimeMode="True" DataField="OperationStopTime_Time" Width="90" ></px:PXGridColumn>
											<px:PXGridColumn DataField="TaskDuration" Width="100" ></px:PXGridColumn>
											<px:PXGridColumn DataField="Uom" Width="72" ></px:PXGridColumn></Columns>
									</px:PXGridLevel>
								</Levels>
								<AutoSize Enabled="True" Container="Parent" MinHeight="150" ></AutoSize>
								<ActionBar>
									<CustomItems>
										<px:PXToolBarButton Text="Clock On" DependOnGrid="">
											<AutoCallBack Target="ds" Command="ClockOn" />
										</px:PXToolBarButton>
										<px:PXToolBarButton Text="Clock Off" DependOnGrid="">
											<AutoCallBack Target="ds" Command="ClockOff" />
										</px:PXToolBarButton>
									</CustomItems>
								</ActionBar>
							</px:PXGrid>
						</Template2>
					</px:PXSplitContainer>
				</Template>
			</px:PXTabItem>
		</Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
	</px:PXTab>
	
</asp:Content>