﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true"
ValidateRequest="false" CodeFile="SP302020.aspx.cs" Inherits="Page_SP302020"
    Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <style>
        .FlxCellGeneratedOpen {
            background-color: greenyellow !important;
            font-weight: bold !important;
        }
        .FlxCellGenerateable {
            background-color: yellow !important;
        }
        .FlxCellCompleted {
            background-color: #CCCCFF !important;
            font-weight: bold !important;
        }
    </style>
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="SNPMFG.Prd.ProductionPlan.Graphs.SPProdPlanMaint" PrimaryView="SPProdPlans">
		<CallbackCommands>
			<px:PXDSCallbackCommand CommitChanges="True" Name="ShowTotals" Visible="False" />
            <px:PXDSCallbackCommand Name="Delete" Visible="true" DependOnGrid="SSPProdPlanItemsGrid" StateColumn="RowDeleteStatus" />
			<px:PXDSCallbackCommand Name="DeletePlanWorkOrders" DependOnGrid="SSPProdPlanItemsGrid" Visible="False"/>
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="SPProdPlans" NoteIndicator="True" TabIndex="100">
		<Template>
			<px:PXLayoutRule runat="server" ControlSize="M" StartColumn="True" LabelsWidth="M" />
			<px:PXSelector ID="edProdPlanNbr" runat="server" DataField="ProdPlanNbr" />
			<px:PXCheckBox runat="server" ID="edIsOnHold" DataField="IsOnHold" Size="S" CommitChanges="True" />
			<px:PXDropDown runat="server" ID="edProdPlanStatus" DataField="Status" CommitChanges="True" Size="S" />
			<px:PXDateTimeEdit runat="server" ID="edPlaningPeriodStart" DataField="PlaningPeriodStart" />
			<px:PXDateTimeEdit runat="server" ID="edPlaningPeriodEnd" DataField="PlaningPeriodEnd" />
			<px:PXDropDown runat="server" ID="edPeriodLength" DataField="PeriodLength" AllowNull="False" />
			<px:PXLayoutRule runat="server" StartColumn="True" />
			<px:PXSelector runat="server" ID="edSeasonalityID" DataField="SeasonalityID" AllowEdit="True"/>
			<px:PXSelector runat="server" ID="edWorkCalendarID" DataField="WorkCalendarID" />
			<px:PXNumberEdit runat="server" ID="edUtilizationRate" DataField="UtilizationRate" CommitChanges="True" />
			<px:PXNumberEdit runat="server" ID="edEmployees" DataField="Employees" CommitChanges="True" />
			<px:PXDropDown runat="server" ID="edPeriodToGenerate" DataField="PeriodToGenerate" CommitChanges="True" Size="S" />
			<px:PXDropDown runat="server" ID="edHistorySource" DataField="HistorySource" CommitChanges="True" />
			<px:PXLayoutRule runat="server" ColumnSpan="2" />
			<px:PXTextEdit ID="edDescription" runat="server" DataField="Description" />
			<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" />
			<px:PXDateTimeEdit runat="server" ID="edLastCalculationTime" DataField="LastCalculationTime" />
			<px:PXNumberEdit runat="server" ID="edWorkingHours" DataField="WorkingHours" CommitChanges="True" Enabled="False" />
		</Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
	<px:PXTab ID="tab" runat="server" Height="423px" Style="z-index: 100;" Width="100%" TabIndex="23" DataSourceID="ds">
		<Items>
			<px:PXTabItem Text="Plan">
				<Template>
					<px:PXGrid ID="SPProdPlanItemsGrid" runat="server" Height="600px" SkinID="DetailsInTab" Style="z-index: 100;" TabIndex="30500" Width="100%" SyncPosition="true" OnRowDataBound="grid_RowDataBound">
						<Levels>
							<px:PXGridLevel DataMember="SPProdPlanItems">
								<RowTemplate>
									<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M" />
									<px:PXSelector runat="server" ID="edInventoryID" DataField="InventoryID" />
									<px:PXDropDown runat="server" ID="edForecastMethod" CommitChanges="True" DataField="ForecastMethod" />
									<px:PXSelector runat="server" ID="edRevisionID" DataField="RevisionID" AutoRefresh="True" />
								</RowTemplate>
								<Columns>
									<px:PXGridColumn DataField="InventoryID" Width="100" CommitChanges="True" />
									<px:PXGridColumn DataField="SubstituteInventoryID" Width="100" CommitChanges="True" />
									<px:PXGridColumn DataField="RevisionID" Width="100" CommitChanges="True" />
									<px:PXGridColumn DataField="ForecastMethod" Type="DropDownList" Width="120" AllowNull="False" />
									<px:PXGridColumn DataField="AutoRegressiveOrder" Width="80" />
									<px:PXGridColumn DataField="DegreeOfDifferencing" Width="80" />
									<px:PXGridColumn DataField="MovingAverageOrder" Width="80" />
									<px:PXGridColumn DataField="HistoricalDataCount" Width="100" TextAlign="Center" AllowNull="True" />
									<px:PXGridColumn DataField="HistoryStartDate" Width="100" />
									<px:PXGridColumn DataField="HistoryEndDate" Width="100" />
									<px:PXGridColumn DataField="Uom" Width="60" />
									<px:PXGridColumn DataField="PlannedQty1" Width="80" />
									<px:PXGridColumn DataField="PlannedQty2" Width="80" />
									<px:PXGridColumn DataField="PlannedQty3" Width="80" />
									<px:PXGridColumn DataField="PlannedQty4" Width="80" />
									<px:PXGridColumn DataField="PlannedQty5" Width="80" />
									<px:PXGridColumn DataField="PlannedQty6" Width="80" />
									<px:PXGridColumn DataField="PlannedQty7" Width="80" />
									<px:PXGridColumn DataField="PlannedQty8" Width="80" />
									<px:PXGridColumn DataField="PlannedQty9" Width="80" />
									<px:PXGridColumn DataField="PlannedQty10" Width="80" />
									<px:PXGridColumn DataField="PlannedQty11" Width="80" />
									<px:PXGridColumn DataField="PlannedQty12" Width="80" />

                                    <px:PXGridColumn DataField="LineNbr" Visible="False" AllowShowHide="False" />

                                    <px:PXGridColumn DataField="P1WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P1Status" Visible="False" AllowShowHide="False" />

                                    <px:PXGridColumn DataField="P2WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P2Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P3WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P3Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P4WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P4Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P5WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P5Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P6WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P6Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P7WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P7Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P8WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P8Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P9WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P9Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P10WrkOrdbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P10Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P11WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P11Status" Visible="False" AllowShowHide="False" />

									<px:PXGridColumn DataField="P12WrkOrdNbr" Visible="False" AllowShowHide="False" />
                                    <px:PXGridColumn DataField="P12Status" Visible="False" AllowShowHide="False" />

                                    <px:PXGridColumn DataField="RowDeleteStatus" />
								</Columns>
							</px:PXGridLevel>
						</Levels>
						<ActionBar ActionsText="False">
							<CustomItems>
								<px:PXToolBarButton Text="Delete Work Orders" DependOnGrid="SPProdPlanItemsGrid" StateColumn="RowDeleteStatus">
									<AutoCallBack Command="DeletePlanWorkOrders" Target="ds">
									</AutoCallBack>
								</px:PXToolBarButton>
							</CustomItems>
						</ActionBar>
						<Mode AllowUpload="True" />
					</px:PXGrid>
				</Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Required Materials">
				<Template>
					<px:PXGrid ID="SPProdPlanNonStockItemsGrid" runat="server" Height="600px" SkinID="DetailsInTab" Style="z-index: 100;" TabIndex="30500" Width="100%" SyncPosition="true">
						<Levels>
							<px:PXGridLevel DataMember="SPProdPlanMaterialItems">
								<RowTemplate>
									<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M" />
									<px:PXSelector runat="server" ID="edNonstockInventoryID" DataField="InventoryID" />
									<px:PXDropDown runat="server" ID="edNonstockForecastMethod" CommitChanges="True" DataField="ForecastMethod" />
									<px:PXDropDown runat="server" ID="edNonstockStatus" CommitChanges="True" DataField="Status" />
								</RowTemplate>
								<Columns>
									<px:PXGridColumn DataField="InventoryID" Width="100" />
									<px:PXGridColumn DataField="Uom" Width="60" />
									<px:PXGridColumn DataField="PlannedQty1" Width="80" />
									<px:PXGridColumn DataField="PlannedQty2" Width="80" />
									<px:PXGridColumn DataField="PlannedQty3" Width="80" />
									<px:PXGridColumn DataField="PlannedQty4" Width="80" />
									<px:PXGridColumn DataField="PlannedQty5" Width="80" />
									<px:PXGridColumn DataField="PlannedQty6" Width="80" />
									<px:PXGridColumn DataField="PlannedQty7" Width="80" />
									<px:PXGridColumn DataField="PlannedQty8" Width="80" />
									<px:PXGridColumn DataField="PlannedQty9" Width="80" />
									<px:PXGridColumn DataField="PlannedQty10" Width="80" />
									<px:PXGridColumn DataField="PlannedQty11" Width="80" />
									<px:PXGridColumn DataField="PlannedQty12" Width="80" />
								</Columns>
							</px:PXGridLevel>
						</Levels>
						<ActionBar>
							<Actions>
								<AddNew Enabled="False" />
								<Delete Enabled="False" />
								<EditRecord Enabled="False" />
							</Actions>
						</ActionBar>
					</px:PXGrid>
				</Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Required Labor">
				<Template>
					<px:PXGrid ID="PXGrid1" runat="server" Height="600px" SkinID="DetailsInTab" Style="z-index: 100;" TabIndex="30500" Width="100%" SyncPosition="true">
						<Levels>
							<px:PXGridLevel DataMember="SPProdPlanLaborItems">
								<RowTemplate>
									<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M" />
									<px:PXSelector runat="server" ID="PXSelector1" DataField="InventoryID" />
									<px:PXDropDown runat="server" ID="PXDropDown1" CommitChanges="True" DataField="ForecastMethod" />
									<px:PXDropDown runat="server" ID="PXDropDown2" CommitChanges="True" DataField="Status" />
								</RowTemplate>
								<Columns>
									<px:PXGridColumn DataField="InventoryID" Width="100" />
									<px:PXGridColumn DataField="Uom" Width="60" />
									<px:PXGridColumn DataField="PlannedQty1" Width="80" />
									<px:PXGridColumn DataField="PlannedQty2" Width="80" />
									<px:PXGridColumn DataField="PlannedQty3" Width="80" />
									<px:PXGridColumn DataField="PlannedQty4" Width="80" />
									<px:PXGridColumn DataField="PlannedQty5" Width="80" />
									<px:PXGridColumn DataField="PlannedQty6" Width="80" />
									<px:PXGridColumn DataField="PlannedQty7" Width="80" />
									<px:PXGridColumn DataField="PlannedQty8" Width="80" />
									<px:PXGridColumn DataField="PlannedQty9" Width="80" />
									<px:PXGridColumn DataField="PlannedQty10" Width="80" />
									<px:PXGridColumn DataField="PlannedQty11" Width="80" />
									<px:PXGridColumn DataField="PlannedQty12" Width="80" />
								</Columns>
							</px:PXGridLevel>
						</Levels>
						<ActionBar>
							<Actions>
								<AddNew Enabled="False" />
								<Delete Enabled="False" />
								<EditRecord Enabled="False" />
							</Actions>
							<CustomItems>
								<px:PXToolBarButton Text="Show Totals">
									<AutoCallBack Command="showTotals" Target="ds" />
								</px:PXToolBarButton>
							</CustomItems>
						</ActionBar>
					</px:PXGrid>
				</Template>
			</px:PXTabItem>
		</Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
		<CallbackCommands>
			<Refresh CommitChanges="True" PostData="Page" />
			<Search CommitChanges="True" PostData="Page" />
		</CallbackCommands>
	</px:PXTab>
	<px:PXSmartPanel ID="PanelShowTotals" runat="server" Key="Totals" CommandSourceID="ds" Caption="Total Working Hours" CaptionVisible="True" LoadOnDemand="True" AutoReload="True">
		<px:PXFormView ID="TotalsForm" runat="server" DataSourceID="ds" DataMember="Totals" Width="1200px" CloseButtonDialogResult="OK">
			<Template>
				<px:PXGrid ID="TotalsGrid" runat="server" Height="200px" SkinID="DetailsInTab" Style="z-index: 100;" TabIndex="30500" Width="100%" SyncPosition="true" AllowPaging="False" NoteIndicator="False" FilesIndicator="False">
					<Levels>
						<px:PXGridLevel DataMember="Totals">
							<RowTemplate>
								<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M" />
								<px:PXTextEdit runat="server" ID="edTotalsLabel" DataField="TotalsLabel" />
							</RowTemplate>
							<Columns>
								<px:PXGridColumn DataField="TotalLabel" Width="130" />
								<px:PXGridColumn DataField="Uom" Width="60" />
								<px:PXGridColumn DataField="PlannedQty1" Width="80" />
								<px:PXGridColumn DataField="PlannedQty2" Width="80" />
								<px:PXGridColumn DataField="PlannedQty3" Width="80" />
								<px:PXGridColumn DataField="PlannedQty4" Width="80" />
								<px:PXGridColumn DataField="PlannedQty5" Width="80" />
								<px:PXGridColumn DataField="PlannedQty6" Width="80" />
								<px:PXGridColumn DataField="PlannedQty7" Width="80" />
								<px:PXGridColumn DataField="PlannedQty8" Width="80" />
								<px:PXGridColumn DataField="PlannedQty9" Width="80" />
								<px:PXGridColumn DataField="PlannedQty10" Width="80" />
								<px:PXGridColumn DataField="PlannedQty11" Width="80" />
								<px:PXGridColumn DataField="PlannedQty12" Width="80" />
							</Columns>
						</px:PXGridLevel>
					</Levels>
				</px:PXGrid>
				<px:PXPanel ID="ButtonfPanel" runat="server" SkinID="Buttons">
					<px:PXButton ID="pxOkButton" runat="server" DialogResult="Ok" Text="Ok" SyncVisible="false" />
				</px:PXPanel>
			</Template>
		</px:PXFormView>
	</px:PXSmartPanel>
</asp:Content>