using System;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using SNPMFG.Prd.DAC;

public partial class  Page_SPTM3030 : PX.Web.UI.PXPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
		
	}

	protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        SPLaborScanDetail row = (SPLaborScanDetail)e.Row.DataItem;
        if (row != null)
        {
            if (row.Selected == true) 
            {
                e.Row.Style.CssClass = "green20";
            }

            if(row.HasUncompletedLine == true && row.Selected == false) 
            {
                e.Row.Style.CssClass = "blue40";
            }
        }
    }
}
