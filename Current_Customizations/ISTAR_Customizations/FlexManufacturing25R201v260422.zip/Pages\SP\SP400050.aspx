<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SP400050.aspx.cs" Inherits="Page_SP400050" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="FlxMFG.WIP.FlxWipInq"
        PrimaryView="Filter"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Width="100%" Height="100px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXLayoutRule LabelsWidth="S" ControlSize="M" runat="server" ID="CstPXLayoutRule3" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector2" DataField="WIPSiteID" ></px:PXSelector>
			<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector1" DataField="WONbr" ></px:PXSelector>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox1" DataField="IncludeSubAssemblies" ></px:PXCheckBox>
			<px:PXLayoutRule LabelsWidth="M" ControlSize="S" runat="server" ID="CstPXLayoutRule6" StartColumn="True" ></px:PXLayoutRule>
			<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit5" DataField="IssueDateRangeStart" ></px:PXDateTimeEdit>
			<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit4" DataField="IssueDateRangeEnd" ></px:PXDateTimeEdit>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox7" DataField="OnlyOpenOrders" ></px:PXCheckBox></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Inquire" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="Items">
			    <Columns>
				<px:PXGridColumn DataField="InventoryID" Width="70" />
				<px:PXGridColumn DataField="InventoryID_InventoryItem_descr" Width="280" />
				<px:PXGridColumn DataField="WONbr" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="WOStatus" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="RootWONbr" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="QtyIssued" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="UnitCost" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="ExtCost" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="TotalIssuesCount" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn DataField="LastIssueDate" Width="120" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowUpload="False" AllowUpdate="False" AllowDelete="False" AllowAddNew="False" ></Mode>
		<Mode AllowDelete="False" ></Mode>
		<Mode AllowUpdate="False" ></Mode>
		<Mode AllowUpload="False" ></Mode></px:PXGrid>
</asp:Content>