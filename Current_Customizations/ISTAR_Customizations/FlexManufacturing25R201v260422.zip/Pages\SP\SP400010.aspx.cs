using System;
using System.Reflection;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Linq;


public partial class Page_SP400010 : PX.Web.UI.PXPage
{
    private MethodInfo methodInfoGridRowStyling;
    protected void Page_Load(object sender, EventArgs e)
    {
        //RegisterStyle("FlxCellGreen", "LightMossGreen", null, false)   
        //RegisterCellWhiteSpeceStyle("FlxGridColWsPre","pre" );

        MethodInfo[] info = this.ds.DataGraph.GetType().GetMethods(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
        MethodInfo meth =info.SingleOrDefault(sod=>sod.Name=="GridRowStyles");
        if(meth != null) 
        {
           List<KeyValuePair<string, System.Web.UI.WebControls.Style>> rowStyles 
                = (List<KeyValuePair<string, System.Web.UI.WebControls.Style>>)meth.Invoke(this.ds.DataGraph,null);

            foreach(KeyValuePair<string, System.Web.UI.WebControls.Style> q in rowStyles) 
            {
                System.Web.UI.WebControls.Style s = (System.Web.UI.WebControls.Style) q.Value;
                string styleName = (string) q.Key;
                 
                this.Page.Header.StyleSheet.CreateStyleRule(s, this, "." + styleName);
            }
        }
        methodInfoGridRowStyling = info.SingleOrDefault(sod=>sod.Name=="GridRowStyling");
    }

    private void RegisterStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor)) style.BackColor = Color.FromName(backColor);
        if (!string.IsNullOrEmpty(foreColor)) style.ForeColor = Color.FromName(foreColor);
        style.Font.Bold = bold;

        this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }

    protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
			//SNPMFG.Prd.SPDAOrderEntry woGraph = this.ds.DataGraph as SNPMFG.Prd.FlxSpecInq;
			//woGraph.GridRowStyling((PX.Web.UI.PXGrid)sender, ref e);
            if(methodInfoGridRowStyling != null)
            {
                object[] arguments = new object[] {sender, e};
                methodInfoGridRowStyling.Invoke(this.ds.DataGraph, arguments);
            }
	}
}

/*
#bfff00
rgb(191,255,0)
Bitter lime
#ccff00
rgb(204,255,0)
Electric lime
#ceff00
rgb(206,255,0)
Volt
#32cd32
rgb(50,205,50)
Lime Green
#3fff00
rgb(63,255,0)
Harlequin
#00fa9a
*/