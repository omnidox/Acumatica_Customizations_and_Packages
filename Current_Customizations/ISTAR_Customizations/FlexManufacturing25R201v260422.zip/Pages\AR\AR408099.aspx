<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="AR408099.aspx.cs" Inherits="Page_AR408099" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="SNPMFG.Prd.AscSalesByCustomerInq" PrimaryView="SalesFilter">
		<CallbackCommands>
            <px:PXDSCallbackCommand Name="ActionRedirectToCustomer" Visible="False"/>
            <px:PXDSCallbackCommand Name="ActionFillData" Visible="False"/>
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView runat="server" DataMember="SalesFilter" ID="frmFilter" Width="100%">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector runat="server" ID="slBranchID" DataField="BranchID"/>
            <px:PXSelector runat="server" ID="slCustomerID" DataField="CustomerID" CommitChanges="True"/>
            <px:PXMultiSelector runat="server" ID="slCustomerClass" DataField="CustomerClass" Width="250px" CommitChanges="True"/>
            <px:PXDateTimeEdit  runat="server" ID="dtStartDate" DataField="StartDate" CommitChanges="True"/>
            <px:PXDateTimeEdit  runat="server" ID="dtEndDate" DataField="EndDate" CommitChanges="True"/>
            <px:PXLayoutRule runat="server" StartRow="False" StartColumn="True"/>
            <px:PXCheckBox runat="server" ID="chkGroupByLocation" DataField="GroupByLocation" CommitChanges="True"/>
            
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phG" runat="Server">
	<px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
		AllowPaging="True" AllowSearch="true" AdjustPageSize="Auto" DataSourceID="ds" SkinID="PrimaryInquire">
		<Levels>
			<px:PXGridLevel DataMember="View">
                <Columns>
                    <px:PXGridColumn DataField="ItemObject" LinkCommand="RedirectToCustomer" DisplayMode="Hint"/>
                    <px:PXGridColumn DataField="Location"/>
                    <px:PXGridColumn DataField="Amount"/>
                    <px:PXGridColumn DataField="PercOfSales"/>
                    <px:PXGridColumn DataField="AvgPrice"/>
                    <px:PXGridColumn DataField="COGS"/>
                    <px:PXGridColumn DataField="AvgCOGS"/>
                    <px:PXGridColumn DataField="GrossMargin"/>
                    <px:PXGridColumn DataField="GrossMarginPerc"/>
<px:PXGridColumn DataField="UOMQty" />
                    <px:PXGridColumn DataField="KitItem" />
                </Columns>
			</px:PXGridLevel>
		</Levels>
        <ActionBar>
            <Actions>
                <Refresh Enabled="False"/>
            </Actions>
        </ActionBar>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
	</px:PXGrid>
</asp:Content>