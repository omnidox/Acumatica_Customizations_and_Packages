<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SP502011.aspx.cs"
    Inherits="Page_SP502011" Title="Mfg Requirements Processing" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="SNPMFG.Prd.SPMfgReqsProcess" PrimaryView="Filter">
		<CallbackCommands>
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Style="z-index: 100" Width="100%">
		<Template>
			<px:PXLayoutRule ControlSize="L" LabelsWidth="XM" runat="server" ID="lmCstPXLayoutRule2" StartRow="True"></px:PXLayoutRule>
			<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="lmCstPXSelector6" DataField="HorizionStart"></px:PXDateTimeEdit>
			<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="lmCstPXSelector7" DataField="HorizionEnd"></px:PXDateTimeEdit>
			<px:PXSegmentMask CommitChanges="True" runat="server" DataField="SiteID" ID="lmedSiteID" ></px:PXSegmentMask>
			<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector1" DataField="ApexOrdNbr" ></px:PXSelector>
			<px:PXSegmentMask CommitChanges="True" ID="editemClass" runat="server" DataField="ItemClassID" ></px:PXSegmentMask>
			 <px:PXSegmentMask ID="edInventoryID" runat="server" DataField="InventoryID" DataSourceID="ds" AutoRefresh="true" CommitChanges="true" AllowEdit="true">
                <GridProperties>
                    <Layout ColumnsMenu="False" ></Layout>
                    <PagerSettings Mode="NextPrevFirstLast" ></PagerSettings>
                    <PagerSettings Mode="NextPrevFirstLast" ></PagerSettings>
                </GridProperties>
                <AutoCallBack Command="Save" Enabled="True" Target="form">
                </AutoCallBack>
            </px:PXSegmentMask>
			<px:PXLayoutRule runat="server" ID="lmCstPXLayoutRule9" StartColumn="True"></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox1" DataField="Reschedule" />
			<px:PXCheckBox CommitChanges runat="server" ID="lmchkBxHold" DataField="IncludeHolds"></px:PXCheckBox>
			<px:PXCheckBox CommitChanges runat="server" ID="lmckkBxPlanned" DataField="IncludePlanned"></px:PXCheckBox>
			<px:PXCheckBox CommitChanges runat="server" ID="lmcmBxShowOnlyReqs" DataField="ReportOnlyRequirements"></px:PXCheckBox></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
	<%--
        <px:PXGrid ID="PXGrid1" runat="server" Height="144px"
		Style="z-index: 100; left: 0px; top: 0px;" Width="100%" AdjustPageSize="Auto"
		AllowPaging="True" AllowSearch="True" BatchUpdate="True" TabIndex="100"
		Caption="Details" DataSourceID="ds" SkinID="PrimaryInquire">--%>
	<px:PXGrid SyncPosition="True" ID="grid" runat="server" DataSourceID="ds" Width="100%"  Height="150px" AllowAutoHide="False" TabIndex="6400">
		<Levels>
			<px:PXGridLevel DataMember="WorkOrders">
				<Columns>
					<px:PXGridColumn AllowNull="False" AllowCheckAll="True" Type="CheckBox" DataField="Selected" Width="50" TextAlign="Center" AllowSort="False"></px:PXGridColumn>
					<px:PXGridColumn AllowUpdate="False" DataField="WrkOrdNbr" Width="100px" LinkCommand="viewDocument"></px:PXGridColumn>
					<px:PXGridColumn DataField="ParentWONbr" Width="100 px" ></px:PXGridColumn>
					<px:PXGridColumn DataField="ApexWrkOrdNbr" Width="100px" ></px:PXGridColumn>
					<px:PXGridColumn AllowUpdate="False" DataField="Status" Width="85px"></px:PXGridColumn>
					<px:PXGridColumn Type="CheckBox" DataField="Hold" Width="60" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CurrentFinishDate" Width="90" ></px:PXGridColumn>
					<px:PXGridColumn DataField="PlannedQty" Width="100" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InventoryID" Width="70" />
					<px:PXGridColumn DataField="InventoryID_description" Width="280" ></px:PXGridColumn>
					<px:PXGridColumn TextAlign="Center" DataField="CompDependencyLeadTime" Width="100px" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
	</px:PXGrid>

	<ActionBar DefaultAction="viewDocument" />

</asp:Content>