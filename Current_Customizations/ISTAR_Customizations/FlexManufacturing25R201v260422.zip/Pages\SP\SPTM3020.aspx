<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false"
    CodeFile="SPTM3020.aspx.cs" Inherits="Page_SPTM3020" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="SNPMFG.Prd.SPTMLaborEntry"
        PrimaryView="filter">
        <CallbackCommands>
            <px:PXDSCallbackCommand CommitChanges="True" Name="Save" />
            <px:PXDSCallbackCommand Name="ClockOn" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ClockOff" Visible="False" CommitChanges="true" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <!-- Variables Globales -->
    <%-- <script type="text/javascript">
        var pageUrl = "<%= pageUrl %>";
        var baseUrl = window.location.protocol + "//" + window.location.host + "<%= applicationName %>" + "/(W(10000))/";
        var startDate = "<%= startDate %>";
        var DefaultEmployee = "<%= DefaultEmployee %>";
        var ExternalEmployee = "<%= ExternalEmployee  %>";
        var ExternalBranchID = "<%= ExternalBranchID  %>";
        var ExternalBranchLocationID = "<%= ExternalBranchLocationID  %>";
        var RefNbr = "<%= RefNbr %>";
        var ExternalCustomerID = "<%= CustomerID %>";
        var ExternalSMEquipmentID = "<%= SMEquipmentID %>";
        var AppSource = "<%= AppSource %>";
    </script>--%>
    <script type="text/javascript">
        function FormView_Load() {
            //px_callback.addHandler(setFocusOnCustRef);
            debugger;
            console.log("ready - FormView_Load - CALLED");
            return;
        }
        //$(function () {
        //    $(document).ready(function () {
        //        console.log("ready");
        //    });
        //});
    </script>
    <px:PXFormView DefaultControlID="CstPXSelector2" NoteIndicator="True" FilesIndicator="True"
        LinkIndicator="True" ActivityIndicator="True" Caption="Work Order Time Entry" ID="form" runat="server"
        DataSourceID="ds" DataMember="filter" Width="100%" AllowAutoHide="false">
        <Template>
            <px:PXLayoutRule runat="server" ID="CstPXLayoutRule3" StartColumn="True" ControlSize="SM" LabelsWidth="S"></px:PXLayoutRule>
            <px:PXSelector runat="server" ID="CstPXSelector2" DataField="WrkOrdNbr" CommitChanges="True"></px:PXSelector>
            <px:PXNumberEdit runat="server" ID="CstPXNumberEdit6" DataField="CurrentDocument.PlannedQty" Enabled="false"></px:PXNumberEdit>
            <px:PXSelector runat="server" ID="CstPXSelector7" DataField="CurrentDocument.UOM" Enabled="false"></px:PXSelector>
            <px:PXLayoutRule runat="server" ID="CstPXLayoutRule4" StartColumn="True" ControlSize="XM" LabelsWidth="S"></px:PXLayoutRule>
            <px:PXTextEdit runat="server" ID="flxEmpNameTextEdit" DataField="CurrentDocument.WrkOrderDescr" Enabled="false"></px:PXTextEdit>
            <px:PXSelector runat="server" ID="CstPXSelector5" DataField="CurrentDocument.InventoryID" Enabled="false"></px:PXSelector>
	<px:PXSegmentMask runat="server" DataField="CurrentDocument.CustomerID" AllowEdit="False" ID="flxWoCustID" />
            <px:PXLayoutRule ControlSize="M" runat="server" ID="PXLayoutRule1" StartColumn="True"></px:PXLayoutRule>
            <px:PXTextEdit runat="server" ID="LMTMte100" DataField="LMTMAccess" CommitChanges="True" TextMode="Password"></px:PXTextEdit>
            <px:PXTextEdit runat="server" ID="LTTMte101" DataField="EmployeeID" Enabled="false"></px:PXTextEdit>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit1xx" DataField="EmployeeAcctName" ></px:PXTextEdit></Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">

    <px:PXSplitContainer runat="server" ID="sp1" SkinID="Horizontal" SplitterPosition="360">
        <AutoSize Enabled="True" Container="Window" ></AutoSize>
        <Template1>
            <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" AllowFilter="True" ActionsPosition="Top"
                SkinID="PrimaryInquire" SyncPosition="true" AdjustPageSize="Auto" AllowPaging="True" Caption="Prod Order Labor Tasks" KeepPosition="True"
                CaptionVisible="true" AutoAdjustColumns="True" PreserveSortsAndFilters="True" PreservePageIndex="True">
                <Levels>
                    <px:PXGridLevel DataMember="Rous">
                        <Mode AllowAddNew="False" AllowDelete="False" AllowUpdate="True" AllowRowSelect="True" ></Mode>
                        <Columns>
                            <px:PXGridColumn DataField="TranDesc" Width="280" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="QtyReqd" Width="100" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="UOM" Width="70" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="LabourConsumedExt" Width="100" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="ItemType" Width="70" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="InventoryID_InventoryItem_descr" Width="280" ></px:PXGridColumn>
                        </Columns>
                    </px:PXGridLevel>
                </Levels>
                <AutoSize Enabled="True" Container="Parent" ></AutoSize>
                <AutoCallBack Command="Refresh" Target="grid2" ></AutoCallBack>
                <ActionBar>
                    <Actions>
                        <Refresh ToolBarVisible="Top" ></Refresh>
                    </Actions>
                </ActionBar>
            </px:PXGrid>
        </Template1>
        <Template2>
            <px:PXGrid ID="grid2" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" Height="260px"
                SkinID="Details" AdjustPageSize="Auto" AllowPaging="True" Caption="Work Record" CaptionVisible="true" SyncPosition="True" AutoAdjustColumns="True">
                <Levels>
                    <px:PXGridLevel DataMember="laborRecs">
                        <Mode AllowAddNew="True" AllowDelete="True" AllowUpdate="True" AllowRowSelect="True" ></Mode>
                        <Columns>
                            <px:PXGridColumn DataField="OperationStartTime_Date" CommitChanges="True" Width="100px" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="OperationStartTime_Time" TimeMode="True" CommitChanges="True" Width="100px" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="OperationStopTime_Date" CommitChanges="True" Width="100px" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="OperationStopTime_Time" TimeMode="True" CommitChanges="True" Width="100px" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="TaskDuration" Width="100" ></px:PXGridColumn>
                            <px:PXGridColumn DataField="UOM" Width="70" ></px:PXGridColumn>
                        </Columns>
                    </px:PXGridLevel>
                </Levels>
                <Mode InitNewRow="True" ></Mode>
                <AutoSize Enabled="True" Container="Parent" MinHeight="150" ></AutoSize>
                <ActionBar>
                    <CustomItems>
                       <px:PXToolBarButton Text="Clock On" DependOnGrid="">
                            <AutoCallBack Target="ds" Command="ClockOn" ></AutoCallBack>
                        </px:PXToolBarButton>
                        <px:PXToolBarButton Text="Clock Off" DependOnGrid="">
                            <AutoCallBack Target="ds" Command="ClockOff" ></AutoCallBack>
                        </px:PXToolBarButton>
                    </CustomItems>
                </ActionBar>
            </px:PXGrid>
        </Template2>
    </px:PXSplitContainer>
</asp:Content>