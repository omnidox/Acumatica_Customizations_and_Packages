<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SP400020.aspx.cs" Inherits="Page_SP400020" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    
   
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="SNPMFG.Prd.FlxIndentedBomEnq" 
        
        PrimaryView="Filter">
        <%-- PageLoadBehavior="PopulateSavedValues" --%>
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Style="z-index: 100" Width="100%">
        <Template>
            <px:PXLayoutRule ControlSize="L" LabelsWidth="XM" runat="server" ID="lmCstPXLayoutRule2" StartRow="True"></px:PXLayoutRule>

            <px:PXSegmentMask AutoRefresh="True"  ID="edKitInventoryID" runat="server" DataField="KitInventoryID" CommitChanges="True">
                <%-- <AutoCallBack Command="Cancel" Target="ds" />
                <GridProperties>
                    <Layout ColumnsMenu="False" />
                </GridProperties> --%>
            </px:PXSegmentMask>
            <px:PXSelector AutoRefresh="True" ID="edRevisionID" runat="server" DataField="RevisionID" CommitChanges="True">
                <%-- <AutoCallBack Command="Cancel" Target="ds" /> --%>
            </px:PXSelector>
	<px:PXCheckBox CommitChanges="True" runat="server" ID="cbIncludeNonStock" DataField="IncludeNonStock" ></px:PXCheckBox>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" />
	<px:PXNumberEdit runat="server" ID="CstPXNumberEdit2" DataField="AssemblyCost" /></Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <%--
        <px:PXGrid ID="PXGrid1" runat="server" Height="144px"
		Style="z-index: 100; left: 0px; top: 0px;" Width="100%" AdjustPageSize="Auto"
		AllowPaging="True" AllowSearch="True" BatchUpdate="True" TabIndex="100"
		Caption="Details" DataSourceID="ds" SkinID="PrimaryInquire">--%>

    <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
		AllowPaging="True" AllowSearch="true" AdjustPageSize="Auto" DataSourceID="ds" SkinID="PrimaryInquire" SyncPosition="True">
        <%-- SkinID="PrimaryInquire" --%>
        <Levels>
            <px:PXGridLevel DataMember="TopToBottomSpec">
                <Columns>
                    <px:PXGridColumn DataField="SpecDescr" Width="400" ></px:PXGridColumn>
                    <px:PXGridColumn Type="CheckBox" DataField="IsKit" Width="60" ></px:PXGridColumn>
	<px:PXGridColumn DataField="CompRevision" Width="120" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="Comment" Width="280" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="QtyPerUOM" Width="100" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="UOM" Width="72" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="UnitCost" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="ExtCost" Width="100" />
                    <px:PXGridColumn DataField="BomLevel" Width="70" ></px:PXGridColumn></Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXGrid>
</asp:Content>