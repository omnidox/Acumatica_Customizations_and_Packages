<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SP102000.aspx.cs" Inherits="Page_SP102000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="SNPMFG.Prd.SPWrkOrderMaint" PrimaryView="WrkOrderSetup">
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="WrkOrderSetup" TabIndex="1900">
		<Template>
			<px:PXLayoutRule runat="server" StartRow="True" LabelsWidth="L" ControlSize="M" StartColumn="True" ></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" StartColumn="True">
			</px:PXLayoutRule>
			<px:PXLayoutRule runat="server" GroupCaption="Reference Settings" StartGroup="True" ColumnWidth="L">
			</px:PXLayoutRule>
			<px:PXSelector ID="edWorkOrderNumberingID" runat="server" DataField="WorkOrderNumberingID">
			</px:PXSelector>
			<px:PXSelector ID="edProdPlanNumberingID" runat="server" DataField="ProdPlanNumberingID">
			</px:PXSelector>
			<px:PXLayoutRule runat="server" GroupCaption="Features" StartGroup="True"></px:PXLayoutRule>
			<px:PXCheckBox ID="lmconsumeAvailableInventory" runat="server" DataField="ConsumeAvailableInv" AlreadyLocalized="False" ></px:PXCheckBox>
			<px:PXCheckBox runat="server" ID="IgnoreSpecQtyVariationCheckBox1" DataField="IgnoreSpecQtyVariation" ></px:PXCheckBox>
			<px:PXCheckBox ID="chkPlanningAllocated" runat="server" DataField="PlanningStatusIsAllocated" AlreadyLocalized="False" ></px:PXCheckBox>
			<px:PXCheckBox ID="lmPXCheckBox2" runat="server" DataField="AutoGenPOForMfg" AlreadyLocalized="False" Enabled="False" ></px:PXCheckBox>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox3" DataField="ErrorOnInsufficientLocationOnHand" ></px:PXCheckBox>
			<px:PXDropDown ID="edpurFulfillType" runat="server" AllowNull="False" DataField="PurchaseFullfilmentPreference" ></px:PXDropDown>
			<px:PXCheckBox ID="chkScheduleLabor" runat="server" DataField="SchedulelaborTasks" AlreadyLocalized="False" ></px:PXCheckBox>
			<px:PXCheckBox ID="chkProcessWOHierarchy" runat="server" DataField="ProcessWOHierarchy" AlreadyLocalized="False" ToolTip="Require dependent Work Orders to be Completed before completing the work order" ></px:PXCheckBox>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox8" DataField="JobShopPricingFeatures" ></px:PXCheckBox>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox9" DataField="EditableDescr" />
			<px:PXSelector runat="server" ID="lmJobshopInventoryID" DataField="JobShopInventoryID" ></px:PXSelector>

			<px:PXLayoutRule runat="server" GroupCaption="Defaults" StartGroup="True"></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox1" DataField="AllowCalendarRestriction" ></px:PXCheckBox>
			<px:PXSelector ID="edWoLaborUnit" runat="server" DataField="WoLaborUnit">
			</px:PXSelector>
			<px:PXSelector ID="edCalendarID" runat="server" DataField="DefLaborCalendarID" DataSourceID="ds" CommitChanges="True" ></px:PXSelector>
			<px:PXNumberEdit ID="edProdDefaultHourlyCost" runat="server" DataField="ProdDefaultHourlyCost" AlreadyLocalized="False" DefaultLocale="">
			</px:PXNumberEdit>
			<px:PXLayoutRule runat="server" GroupCaption="Developer Tools" StartGroup="True"></px:PXLayoutRule>
			<px:PXCheckBox ID="lmactivateDiagnostics" runat="server" DataField="Diagnostics" AlreadyLocalized="False" ></px:PXCheckBox>
			<px:PXTextEdit ID="lmDebugTarget" runat="server" DataField="LoggingURLAndPort" ></px:PXTextEdit>
			<px:PXSelector ID="lmDumpInv" runat="server" DataField="MRPDumpInventoryID">
			</px:PXSelector>
			<px:PXCheckBox ID="lmUnlockKit" runat="server" DataField="UnRestrictKit" AlreadyLocalized="False"></px:PXCheckBox>
			<px:PXTextEdit ID="lmDataSource" runat="server" DataField="ConnectedServer" ></px:PXTextEdit>
			<px:PXTextEdit ID="lmConnectedDB" runat="server" DataField="ConnectedDB" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit7" DataField="ProductVersion" ></px:PXTextEdit></Template>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
	</px:PXFormView>
</asp:Content>