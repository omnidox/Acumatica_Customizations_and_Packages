<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="SP302011.aspx.cs" Inherits="Page_SP302011" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	    <style>
        .FlxRowYellow {
            background-color: yellow !important;
        }
        .FlxCellGreen {
            background-color: greenyellow !important;
            font-weight: bold !important;
        }
		.FlxLocationOnHandWarn {
			color: #ffa600;
			font-weight: bold;
		}
		.FlxLocationOnHandNeg {
			color: white !important;
			font-weight: bold;
			background-color: #f67057 !important;
		}
		.FlxPurchasedNotReceived {
			background-color: #ddf2b5;
		}
		.FlxPurchasedReceived {
			background-color: #7ba827;
		}
		</style>
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="SNPMFG.Prd.SPDAOrderEntry" PrimaryView="WrkOrdersView">
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="ViewDetails" Visible="false" DependOnGrid="componentsGrid" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="ViewSubAssyWO" Visible="false" DependOnGrid="componentsGrid" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="DeleteSubAssembly" Visible="false" DependOnGrid="componentsGrid" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="CreateSubAssembly" Visible="false" DependOnGrid="componentsGrid" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="ViewAllocationDetails" Visible="false" DependOnGrid="componentsGrid" ></px:PXDSCallbackCommand>

			<px:PXDSCallbackCommand Name="HardAllocate" Visible="false" DependOnGrid="componentsGrid" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="RepairReceipt" Visible="false" DependOnGrid="componentsGrid" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="ImportSubAssemblyCost" Visible="false" DependOnGrid="componentsGrid" ></px:PXDSCallbackCommand>

			<px:PXDSCallbackCommand Name="ViewROUDetails" Visible="false" DependOnGrid="laborGrid" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Visible="False" Name="ViewKitStatus"></px:PXDSCallbackCommand>

			<px:PXDSCallbackCommand Name="RecalcPlannedCost" Visible="false" CommitChanges="true" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="PriceToSalesOrder" Visible="false" CommitChanges="True" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="BatchNbr" Visible="false" CommitChanges="true" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="completePartial" Visible="false" DependOnGrid="partCompGrid" CommitChanges="True" StateColumn="CompletePartialButtonEnabled" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="createPurchaseOrder" Visible="false" DependOnGrid="laborGrid" CommitChanges="True" StateColumn="CreatePurchaseOrderButtonEnabled" ></px:PXDSCallbackCommand>

			<px:PXDSCallbackCommand Name="PasteLine" Visible="False" DependOnGrid="laborGrid" CommitChanges="true" ></px:PXDSCallbackCommand>
 			<px:PXDSCallbackCommand Name="ResetOrder" Visible="False" DependOnGrid="laborGrid" CommitChanges="true" ></px:PXDSCallbackCommand>

			<px:PXDSCallbackCommand CommitChanges="True" Name="Action" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand CommitChanges="True" Name="Save" ></px:PXDSCallbackCommand>

			<px:PXDSCallbackCommand Name="ReviewBuildSpec" Visible="false" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="RebuildMfgAllocations" Visible="false" ></px:PXDSCallbackCommand>
			
			<px:PXDSCallbackCommand Name="MRPShallowCalc" Visible="false" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="MRPNadirCalc" Visible="false" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="PriceToDoc" Visible="False" CommitChanges="True" /></CallbackCommands>
			
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="WrkOrdersView" Width="100%" Style="z-index: 100" TabIndex="100">
		<Template>
			<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
			<px:PXJavaScript runat="server" ID="CstJavaScript3" Script="function onPopupClose() { debugger; }" />
			<px:PXSelector ID="edWrkOrdNbr" runat="server" DataField="WrkOrdNbr">
			</px:PXSelector>

			<px:PXCheckBox CommitChanges="True" ID="chkHold" runat="server" DataField="Hold" AlreadyLocalized="False"></px:PXCheckBox>
			<px:PXDropDown ID="edStatus" runat="server" DataField="Status">
			</px:PXDropDown>
			<px:PXTextEdit ID="edDemandRefType" runat="server" DataField="DemandRefType" AlreadyLocalized="False">
			</px:PXTextEdit>
			<px:PXTextEdit Enabled="False" ID="edDemandRef" runat="server" DataField="DemandRef" AlreadyLocalized="False">
			
				<LinkCommand Command="testbed" ></LinkCommand>
				<LinkCommand Target="ds" ></LinkCommand></px:PXTextEdit>
			<px:PXSegmentMask CommitChanges="True" ID="edCustomerID" runat="server" DataField="CustomerID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True"></px:PXSegmentMask>
			<px:PXTextEdit ID="edParentWONbr" runat="server" DataField="ParentWONbr" AlreadyLocalized="False" Enabled="false" AllowEdit="True">
				<LinkCommand Target="ds" Command="viewParentWO"></LinkCommand>
			</px:PXTextEdit>

			<px:PXTextEdit ID="edKitRefNbr" runat="server" DataField="KitRefNbr" Enabled="false" AllowEdit="True">
                        <LinkCommand Target="ds" Command="viewKitSlave"></LinkCommand>
            </px:PXTextEdit>

			<px:PXDropDown ID="edKitStatus" runat="server" DataField="KitStatus">
			</px:PXDropDown>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit10" DataField="UsrWipCompletionTrans" />
			<px:PXLayoutRule runat="server" GroupCaption="Scrap" StartGroup="True"></px:PXLayoutRule>
			<px:PXTextEdit Enabled="False" runat="server" ID="CstPXTextEdit24" DataField="AdjRefNbrScrap" >
				<LinkCommand Target="ds" Command="viewScrapAdj" ></LinkCommand></px:PXTextEdit>
			<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M"></px:PXLayoutRule>
			<px:PXSegmentMask runat="server" ID="CstPXSegmentMask7" DataField="InventoryID" CommitChanges="True" />
			<px:PXCheckBox ID="edStockedItem" runat="server" DataField="StockedItem" Text="Stocked Item" AlreadyLocalized="False">
			</px:PXCheckBox>
			<px:PXCheckBox ID="chkConsumeMfgStock" runat="server" DataField="ConsumeAvailableInv" CommitChanges="True" AlreadyLocalized="False"></px:PXCheckBox>
			<px:PXCheckBox ID="chkReqdCustApproval" runat="server" DataField="ReqdCustApproval" CommitChanges="True" AlreadyLocalized="False" Enabled="False"></px:PXCheckBox>
			<px:PXCheckBox ID="chkRepair" runat="server" DataField="IsrepairWO" AlreadyLocalized="False" Enabled="False"></px:PXCheckBox>
			<px:PXSelector CommitChanges="True" ID="edUOM" runat="server" DataField="UOM">
			</px:PXSelector>
			<px:PXLabel runat="server" ID="FlxLabel2" />
			<px:PXDateTimeEdit ID="edProdPlannedDate" runat="server" DataField="ProdPlannedDate" AlreadyLocalized="False" CommitChanges="True">
			</px:PXDateTimeEdit>
			<px:PXDateTimeEdit ID="edProdRevisedDate" runat="server" DataField="ProdRevisedDate" AlreadyLocalized="False" CommitChanges="True">
			</px:PXDateTimeEdit>
			<px:PXNumberEdit Required="True" CommitChanges="True" ID="edPlannedQty" runat="server" DataField="PlannedQty" AlreadyLocalized="False">
			</px:PXNumberEdit>
			<px:PXNumberEdit runat="server" ID="CstPXNumberEdit4" DataField="JobShopDisplayQty"></px:PXNumberEdit>
			<px:PXNumberEdit runat="server" ID="CstPXNumberEdit5" DataField="JobShopCustomerQty" ></px:PXNumberEdit>

			<px:PXLayoutRule runat="server" ColumnSpan="2"></px:PXLayoutRule>
			<px:PXTextEdit ID="edWrkOrderDescr" runat="server" DataField="WrkOrderDescr" AlreadyLocalized="False"></px:PXTextEdit>

			<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="S" StartGroup="True"></px:PXLayoutRule>
			<px:PXPanel ID="ASCPXPanel1" runat="server" ContentLayout-Layout="Stack" RenderSimple="True" RenderStyle="Simple" AlreadyLocalized="False" DataMember="">
				<px:PXSelector ID="edKitSpecRevisionNumber" runat="server" DataField="KitSpecRevisionNumber" AutoRefresh="true" CommitChanges="true">
					<%-- <AutoCallBack Command="Cancel" Target="ds" /> causes cancel to be fired back to page, do no want that --%>
				</px:PXSelector>
				<px:PXSegmentMask CommitChanges="True" ID="edSiteID" runat="server" DataField="SiteID" AutoRefresh="true">
				</px:PXSegmentMask>
				<px:PXSelector runat="server" ID="CstPXSelector9" DataField="UsrWipSiteID" />
				<px:PXSegmentMask CommitChanges="True" ID="edLocationID" runat="server" DataField="LocationID" AutoRefresh="true">
				</px:PXSegmentMask>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit17" DataField="AllocationLabel" ></px:PXTextEdit>
				<px:PXSelector ID="lmcustApprovalAcknowledged" runat="server" DataField="CustApprovalAcknowledged">
				</px:PXSelector>
				<px:PXLabel Size="xs" ID="lblDays2" runat="server" AlreadyLocalized="False"></px:PXLabel>
				<px:PXDateTimeEdit ID="edProdCompletedDate" CommitChanges="True" runat="server" DataField="ProdCompletedDate" AlreadyLocalized="False">
				</px:PXDateTimeEdit>
				<px:PXNumberEdit ID="edCompDependencyLeadTime" runat="server" DataField="CompDependencyLeadTime" AlreadyLocalized="False">
				</px:PXNumberEdit>
				<px:PXNumberEdit ID="edProducedQty" CommitChanges="True" runat="server" DataField="ProducedQty" AlreadyLocalized="False"></px:PXNumberEdit>				
				<px:PXNumberEdit ID="edDisplayProducedQty" runat="server" DataField="DisplayProducedQty" AlreadyLocalized="False"></px:PXNumberEdit>
				<px:PXNumberEdit runat="server" ID="CstPXNumberEdit18" DataField="OpenQty" ></px:PXNumberEdit>
				<px:PXMaskEdit runat="server" ID="CstPXMaskEdit3" DataField="JobShopCustomerUOM"></px:PXMaskEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEditJobShopCustomerSKU" DataField="JobShopCustomerSKU"></px:PXTextEdit></px:PXPanel></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
	<px:PXTab ID="tab" runat="server" Height="423px" Style="z-index: 100;" Width="100%" TabIndex="23" DataSourceID="ds">
		<Activity HighlightColor="" SelectedColor="" Width="" Height=""></Activity>
		<Items>
			<px:PXTabItem Text="Materials">
				<Template>
					<px:PXGrid FilesIndicator="True" NoteIndicator="True" runat="server" ID="componentsGrid" DataSourceID="ds" SkinID="DetailsInTab" Width="100%" StatusField="Availability" TabIndex="10300" SyncPosition="True" OnRowDataBound="grid_RowDataBound">
						<Mode InitNewRow="True"></Mode>
						<Levels>
							<px:PXGridLevel DataMember="Boms">
								<RowTemplate>
									<px:PXLayoutRule runat="server" ControlSize="M" LabelsWidth="SM" StartColumn="True" StartRow="True">
									</px:PXLayoutRule>
									<px:PXSegmentMask ID="edInventoryID" runat="server" DataField="InventoryID" Width="81px" AllowAddNew="True" AllowEdit="True" AutoRefresh="True">
										<Items>
											<px:PXMaskItem EditMask="AlphaNumeric" Length="10" Separator="-" TextCase="Upper"></px:PXMaskItem>
										</Items>
										<GridProperties FastFilterFields="Descr">
											<PagerSettings Mode="NextPrevFirstLast"></PagerSettings>
											<PagerSettings Mode="NextPrevFirstLast"></PagerSettings>
										</GridProperties>
									</px:PXSegmentMask>
									<px:PXLayoutRule runat="server" ControlSize="M" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>
									<px:PXLayoutRule runat="server" ColumnSpan="2" ColumnWidth="XL" LabelsWidth="SM">
									</px:PXLayoutRule>
									<px:PXTextEdit ID="edTranDesc" runat="server" DataField="TranDesc" Width="380px" AlreadyLocalized="False" DefaultLocale="">
									</px:PXTextEdit>

									<px:PXLayoutRule runat="server" StartRow="True">
									</px:PXLayoutRule>
									<px:PXLayoutRule runat="server" ControlSize="M" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>

									<px:PXNumberEdit ID="edUnitCost" runat="server" DataField="UnitCost" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>

									<px:PXNumberEdit ID="edQtyReqd" runat="server" DataField="QtyReqd" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXLayoutRule runat="server" ControlSize="M" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>

									<px:PXSelector ID="edUOM" runat="server" DataField="UOM" CommitChanges="True">
									</px:PXSelector>

									<px:PXNumberEdit ID="edQtyPerUOM" runat="server" DataField="QtyPerUOM" CommitChanges="True" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXNumberEdit ID="edQtyAvailInventory" runat="server" DataField="QtyAvailInventory" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXLayoutRule runat="server" ControlSize="S" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>
									<px:PXCheckBox ID="edIsRepairItem" runat="server" DataField="IsRepairItem" Text="For Repair" AlreadyLocalized="False">
									</px:PXCheckBox>
									<px:PXCheckBox ID="edIsSubAssy" runat="server" DataField="IsSubAssy" Text="Is Sub Assy" AlreadyLocalized="False">
									</px:PXCheckBox>
									<px:PXCheckBox ID="edIsSerialozed" runat="server" DataField="IsSerialized" Text="Serilized Component" AlreadyLocalized="False">
									</px:PXCheckBox>
									<px:PXSelector AllowEdit="True" Enabled="False" runat="server" ID="FlxSelector13" DataField="TransferRefNbr" ></px:PXSelector>
									<px:PXNumberEdit ID="edQtyHardAlloc" runat="server" DataField="QtyHardAllocated" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>

									<px:PXLayoutRule runat="server" StartRow="True">
									</px:PXLayoutRule>
									<px:PXLayoutRule runat="server" ControlSize="M" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>
									<px:PXNumberEdit ID="edQtyToBeOrdered" runat="server" DataField="QtyToBeOrdered" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXNumberEdit ID="edQtyToBeProduced" runat="server" DataField="QtyToBeProduced" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXNumberEdit runat="server" ID="FlxNumberEdit14" DataField="ActualHardAllocated" ></px:PXNumberEdit>
									<px:PXLayoutRule runat="server" ControlSize="XM" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>
									<px:PXNumberEdit ID="edQtyOnOrder" runat="server" DataField="QtyOnOrder" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXDropDown ID="edProductionMethod" runat="server" DataField="ProductionMethod">
									</px:PXDropDown>
									<px:PXLayoutRule runat="server" ControlSize="M" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>

									<px:PXTextEdit ID="edPOOrderNbr" runat="server" DataField="POOrderNbr" Enabled="False" AllowEdit="True"></px:PXTextEdit>

									<px:PXSelector ID="sltrVendorID" runat="server" DataField="VendorID" AllowEdit="True" CommitChanges="True"></px:PXSelector>
									<px:PXSelector ID="edProdRefNbr" runat="server" DataField="ProdRefNbr"></px:PXSelector>
									<px:PXGridColumn DataField="SubDeleteVisible" Width="60"></px:PXGridColumn>
									<px:PXGridColumn DataField="SubCreateVisible" Width="60"></px:PXGridColumn>
									<px:PXTextEdit ID="edProdRefStatus" runat="server" DataField="ProdRefStatus"></px:PXTextEdit>

									<px:PXLayoutRule runat="server" StartRow="True">
									</px:PXLayoutRule>
									<px:PXLayoutRule runat="server" ControlSize="M" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>
									<px:PXNumberEdit ID="edQtyConsumed" runat="server" DataField="QtyConsumed" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXNumberEdit ID="edQtyScrapped" runat="server" DataField="QtyScrapped" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXNumberEdit ID="edVLeadTime" runat="server" DataField="VLeadTime" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXLayoutRule runat="server" ControlSize="XM" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>
									<px:PXLayoutRule runat="server" ControlSize="M" LabelsWidth="SM" StartColumn="True">
									</px:PXLayoutRule>
									<px:PXSegmentMask ID="edLocationID" runat="server" DataField="LocationID" AutoRefresh="True"></px:PXSegmentMask>
								</RowTemplate>
								<Columns>
									<px:PXGridColumn DataField="RepairReceiptEnabled" Width="60" ></px:PXGridColumn>
									<px:PXGridColumn DataField="InventoryID" AllowNull="False" DisplayFormat="&gt;AAAAAAAAAAAAAAAAAAAAAAAAA" Width="81px" LinkCommand="viewDetails" AutoCallBack="True"></px:PXGridColumn>
									<px:PXGridColumn AllowFilter="True" DataField="LocationID" DisplayFormat="&gt;CCCCCC-CCCC" AutoCallBack="True"></px:PXGridColumn>
									<px:PXGridColumn DataField="LocationOnHand" Width="100" ></px:PXGridColumn>

									<px:PXGridColumn DataField="IsRepairItem" TextAlign="Center" Type="CheckBox" Width="60px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="IsSubAssy" TextAlign="Center" Type="CheckBox" Width="60px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="IsSerialized" TextAlign="Center" Type="CheckBox" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" TextAlign="Center" Type="CheckBox" DataField="CostIsImported" Width="60" ></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="UnitCost" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="UOM" Width="100px" CommitChanges="True">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="UsrWipQtyIssued" Width="70" CommitChanges="True" TextAlign="Right" />
									<px:PXGridColumn DataField="UsrClpPricnCompMU" Width="70" CommitChanges="True" TextAlign="Right" />
									<px:PXGridColumn DataField="UsrWipQtyKitConsumed" Width="70" CommitChanges="True" TextAlign="Right" />
									<px:PXGridColumn DataField="UsrClpPricnCompExtSalePriceContrib" Width="70" TextAlign="Right" />
									<px:PXGridColumn DataField="UsrClpPricnUnitPrice" Width="100" CommitChanges="True" />
									<px:PXGridColumn DataField="UsrClpPricnPriceSource" Width="140" CommitChanges="True" />
									<px:PXGridColumn DataField="QtyPerUOM" TextAlign="Right" Width="100px" CommitChanges="True">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="QtyReqd" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="QtyAvailInventory" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="ProductionMethod"></px:PXGridColumn>
									<px:PXGridColumn TextAlign="Center" Type="CheckBox" DataField="MarkForPO" Width="60" ></px:PXGridColumn>
									<px:PXGridColumn TextAlign="Center" Type="CheckBox" DataField="HardAllocateAvailable" Width="60" ></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" TextAlign="NotSet" DataField="AllocationLocationID" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ActualHardAllocated" TextAlign="Right" Width="85px">
									</px:PXGridColumn>
									<px:PXGridColumn TextAlign="Right" DataField="TransferRefNbr" Width="105" ></px:PXGridColumn>
									<px:PXGridColumn DataField="QtyToBeProduced" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="ProdRefNbr" Width="100px" LinkCommand="viewSubAssyWO" AutoCallBack="True">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="SubDeleteVisible" Type="CheckBox" TextAlign="Center" Width="85px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="SubCreateVisible" Type="CheckBox" TextAlign="Center" Width="85px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="ProdRefStatus" Width="70">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="QtyToBeOrdered" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="VLeadTime" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="QtyOnOrder" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="POOrderNbr" TextAlign="Right" Width="100px" LinkCommand="viewPO" >
									</px:PXGridColumn>
									<px:PXGridColumn DataField="Postatus" TextAlign="Center" Width="140px">
									</px:PXGridColumn>
									<px:PXGridColumn TextAlign="Center" Type="CheckBox" DataField="PurchdGoodsRecvd" Width="75" ></px:PXGridColumn>
									<px:PXGridColumn DataField="VendorID" Width="81px"></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="QtyConsumed" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn AllowNull="False" AllowCheckAll="True" Type="CheckBox" DataField="Selected" Width="50" TextAlign="Center" AllowSort="False">
									</px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="QtyScrapped" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="TranDesc" Width="300px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="StateColumnImportSubAssyCost" Width="60" ></px:PXGridColumn></Columns>
							</px:PXGridLevel>
						</Levels>
						<AutoSize Enabled="True" MinHeight="150"></AutoSize>
						<ActionBar ActionsText="False">
							<CustomItems>
								<px:PXToolBarButton Text="Allocation Details" DependOnGrid="componentsGrid">
									<AutoCallBack Command="ViewAllocationDetails" Target="ds"></AutoCallBack>
								</px:PXToolBarButton>

								<px:PXToolBarButton Text="Hard Allocate" DependOnGrid="componentsGrid" StateColumn="HardAllocateAvailable">
									<AutoCallBack Command="HardAllocate" Target="ds"></AutoCallBack>
								</px:PXToolBarButton>

								<px:PXToolBarButton Text="Clear/Delete SubAssy" DependOnGrid="componentsGrid" StateColumn="SubDeleteVisible">
									<AutoCallBack Command="DeleteSubAssembly" Target="ds"></AutoCallBack>
								</px:PXToolBarButton>

								<px:PXToolBarButton Text="Create SubAssy" DependOnGrid="componentsGrid" StateColumn="SubCreateVisible">
									<AutoCallBack Command="CreateSubAssembly" Target="ds"></AutoCallBack>
								</px:PXToolBarButton>
								<px:PXToolBarButton Text="Import Sub Assy Cost" DependOnGrid="componentsGrid" StateColumn="StateColumnImportSubAssyCost">
									<AutoCallBack Target="ds" Command="ImportSubAssemblyCost" ></AutoCallBack></px:PXToolBarButton>

								<px:PXToolBarButton Text="Repair Item Receipt" DependOnGrid="componentsGrid" StateColumn="RepairReceiptEnabled">
									<AutoCallBack Command="RepairReceipt" Target="ds"></AutoCallBack>
								</px:PXToolBarButton></CustomItems>
						</ActionBar>
					</px:PXGrid>
				</Template>
			</px:PXTabItem>
			<px:PXTabItem Text="WIP Transactions" Visible="True">
				<Template>
					<px:PXGrid runat="server" ID="gridWipXFr" SyncPosition="True" SkinID="">
						<Levels>
							<px:PXGridLevel DataMember="wipXfr">
								<Columns>
									<px:PXGridColumn DataField="RefNbr" Width="140" LinkCommand="viewWIPIssueXfr" />
									<px:PXGridColumn DataField="Status" Width="70" />
									<px:PXGridColumn DataField="TranDate" Width="90" />
									<px:PXGridColumn DataField="TranDesc" Width="280" />
									<px:PXGridColumn DataField="TotalCost" Width="100" /></Columns></px:PXGridLevel></Levels>
						<AutoSize Enabled="True" MinHeight="150" /></px:PXGrid></Template></px:PXTabItem>


			<px:PXTabItem Text="Labor / NonStock Items">
				<Template>
					<px:PXGrid NoteIndicator="True" FilesIndicator="True" ID="laborGrid" runat="server" DataSourceID="ds" BorderStyle="None" Width="100%" SkinID="DetailsInTab" SyncPosition="true">
						<AutoSize Enabled="True" MinHeight="150"></AutoSize>
						<Levels>
							<px:PXGridLevel DataMember="Rous">
								<RowTemplate>
									<px:PXSegmentMask Width="81px" ID="edROUInventoryID" runat="server" DataField="InventoryID" AllowEdit="True">
										<Items>
											<px:PXMaskItem EditMask="AlphaNumeric" Length="10" Separator="-" TextCase="Upper"></px:PXMaskItem>
										</Items>
										<GridProperties FastFilterFields="Descr">
											<PagerSettings Mode="NextPrevFirstLast"></PagerSettings>
											<PagerSettings Mode="NextPrevFirstLast"></PagerSettings>
										</GridProperties>
									</px:PXSegmentMask>
									<px:PXDropDown ID="edItemType" runat="server" DataField="ItemType">
									</px:PXDropDown>
									<px:PXNumberEdit ID="edROUQtyPerUOM" runat="server" DataField="QtyPerUOM" AlreadyLocalized="False" DefaultLocale="" CommitChanges="True">
									</px:PXNumberEdit>
									<px:PXNumberEdit ID="edROUQtyReqd" runat="server" DataField="QtyReqd" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXNumberEdit ID="edROUQtyConsumed" runat="server" DataField="QtyConsumed" CommitChanges="True" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXSelector ID="edROUUOM" runat="server" DataField="UOM" CommitChanges="True" AutoRefresh="True">
									</px:PXSelector>
									<%-- <px:PXNumberEdit ID="edBaseUnitCost" runat="server" DataField="BaseUnitCost" AlreadyLocalized="False" DefaultLocale="">
                                    </px:PXNumberEdit> --%>
									<px:PXNumberEdit ID="edROUUnitCost" runat="server" DataField="UnitCost" AlreadyLocalized="False" DefaultLocale="">
									</px:PXNumberEdit>
									<px:PXTextEdit ID="edROUTranDesc" runat="server" DataField="TranDesc" AlreadyLocalized="False" DefaultLocale="">
									</px:PXTextEdit>
									<px:PXSelector ID="edNonStockPOOrderNbr" runat="server" DataField="POOrderNbr" Enabled="False" AllowEdit="True"></px:PXSelector>
									
									<px:PXSelector ID="edNonStockVendorID" runat="server" DataField="VendorID" AllowEdit="True" CommitChanges="True"></px:PXSelector>
									<px:PXTextEdit ID="edNonStockPostatus" runat="server" DataField="Postatus"></px:PXTextEdit>

									<px:PXDateTimeEdit ID="edOperationStartDate" runat="server" DataField="OperationStartTime_Date" CommitChanges="True"></px:PXDateTimeEdit>
									<px:PXDateTimeEdit ID="edOperationStartTime" runat="server" DataField="OperationStartTime_Time" TimeMode="True" CommitChanges="True"></px:PXDateTimeEdit>
									<px:PXDateTimeEdit ID="edOperationStopDate" runat="server" DataField="OperationStopTime_Date" CommitChanges="True"></px:PXDateTimeEdit>
									<px:PXDateTimeEdit ID="edOperationStopTime" runat="server" DataField="OperationStopTime_Time" TimeMode="True" CommitChanges="True"></px:PXDateTimeEdit>
									<px:PXDateTimeEdit ID="edMaterialAvailability" runat="server" DataField="MaterialAvailability" AlreadyLocalized="False">
									</px:PXDateTimeEdit>
									<px:PXCheckBox ID="edSMaterialAvailabilityLocked" runat="server" DataField="MaterialAvailabilityLocked" AlreadyLocalized="False">
									</px:PXCheckBox>
								</RowTemplate>
								<Columns>
									<px:PXGridColumn DataField="LaborRecordCntr" Width="70"></px:PXGridColumn>
									<px:PXGridColumn DataField="InventoryID" DisplayFormat="&gt;AAAAAAAAAAAAAAAAAAAAAAAAA" Width="81px" LinkCommand="viewROUDetails" AutoCallBack="True"></px:PXGridColumn>
									<px:PXGridColumn DataField="itemtype" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="LineNbr" TextAlign="Right" Visible="False" ></px:PXGridColumn>
									<px:PXGridColumn DataField="uom" Width="60px" CommitChanges="True">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="qtyperuom" TextAlign="right" Width="100px" CommitChanges="True">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="qtyreqd" TextAlign="right" Width="100px" CommitChanges="True">
									</px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="unitcost" TextAlign="right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn AllowNull="False" AllowCheckAll="True" Type="CheckBox" DataField="Selected" Width="50" TextAlign="Center" AllowSort="False">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="qtyconsumed" CommitChanges="True" TextAlign="right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="trandesc" Width="200px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="UsrClpPricnCompMU" Width="100" CommitChanges="True" />
									<px:PXGridColumn DataField="UsrClpPricnUnitPrice" Width="100" CommitChanges="True" />
									<px:PXGridColumn DataField="UsrClpPricnNonStockExt" Width="100" />
									<px:PXGridColumn DataField="UsrClpPricnExt" Width="100" />
									<px:PXGridColumn DataField="UsrClpPricnLaborExt" Width="100" />
									<px:PXGridColumn DataField="POOrderNbr" TextAlign="Right" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="Postatus" TextAlign="Center" Width="140px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="VendorID" Width="81px"></px:PXGridColumn>
									<px:PXGridColumn DataField="ResourceAllocation" Width="100" ></px:PXGridColumn>

									<px:PXGridColumn DataField="OperationStartTime_Date" CommitChanges="True" Width="100px"></px:PXGridColumn>
									<px:PXGridColumn DataField="OperationStartTime_Time" TimeMode="True" CommitChanges="True" Width="100px"></px:PXGridColumn>
									<px:PXGridColumn DataField="OperationStopTime_Date" CommitChanges="True" Width="100px"></px:PXGridColumn>
									<px:PXGridColumn DataField="OperationStopTime_Time" TimeMode="True" CommitChanges="True" Width="100px"></px:PXGridColumn>
									<px:PXGridColumn DataField="createPurchaseOrderButtonEnabled" Type="CheckBox"></px:PXGridColumn></Columns>
							</px:PXGridLevel>
						</Levels>
						<ActionBar ActionsText="False">
							<CustomItems>
								<px:PXToolBarButton Text="Create PO" DependOnGrid="laborGrid" StateColumn="createPurchaseOrderButtonEnabled">
									<AutoCallBack Command="CreatePurchaseOrder" Target="ds">
										<Behavior CommitChanges="True"></Behavior>
									</AutoCallBack>
								</px:PXToolBarButton>
							</CustomItems>
						</ActionBar>

						<Mode InitNewRow="True" AllowDragRows="True" AllowFormEdit="True"></Mode>
						<CallbackCommands PasteCommand="PasteLine">
                            <Save PostData="Container" ></Save>
                        </CallbackCommands>
					</px:PXGrid>
				</Template>
			</px:PXTabItem>

			<px:PXTabItem Text="Partial Completions" Visible="True">
				<Template>
					<px:PXGrid ID="partCompGrid" runat="server" DataSourceID="ds" SyncPosition="True" BorderStyle="None" Width="100%" SkinID="Details">
						<EmptyMsg AnonFilteredAddMessage="No records found.Try to change filter to see records here." AnonFilteredMessage="No records found.Try to change filter to see records here." ComboAddMessage="No records found.Try to change filter or modify parameters above to see records here." FilteredAddMessage="No records found.Try to change filter to see records here." FilteredMessage="No records found.Try to change filter to see records here." NamedComboAddMessage="No records found as '{0}'.Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as '{0}'.Try to change filter or modify parameters above to see records here." NamedFilteredAddMessage="No records found as '{0}'.Try to change filter to see records here." NamedFilteredMessage="No records found as '{0}'.Try to change filter to see records here."></EmptyMsg>
						<AutoSize Enabled="True" MinHeight="150"></AutoSize>
						<Levels>
							<px:PXGridLevel DataMember="PartCompletions">

								<RowTemplate>
									<px:PXDateTimeEdit ID="edpcTranDate" runat="server" DataField="TranDate" AlreadyLocalized="False" DefaultLocale=""></px:PXDateTimeEdit>
									<px:PXNumberEdit ID="edpQtyToComplete" runat="server" DataField="QtyToComplete" AlreadyLocalized="False" DefaultLocale=""></px:PXNumberEdit>--%>
									<px:PXNumberEdit ID="edpcQtyCompleted" runat="server" DataField="QtyCompleted" AlreadyLocalized="False" DefaultLocale=""></px:PXNumberEdit>--%>
									<px:PXSelector ID="edpcRefNbr" runat="server" DataField="KitRefNbr" Enabled="False" AllowEdit="True"></px:PXSelector>
									<px:PXTextEdit ID="edRefStatus" runat="server" DataField="KitStatus" Enabled="False" AlreadyLocalized="False" DefaultLocale=""></px:PXTextEdit>
								</RowTemplate>
								<Columns>
									<px:PXGridColumn DataField="TranDate" DataType="DateTime" Width="90px">
										<Header Text="Due Date">
										</Header>
									</px:PXGridColumn>
									<px:PXGridColumn DataField="QtyToComplete" Width="100" />
									<px:PXGridColumn DataField="QtyCompleted" DataType="Decimal" TextAlign="Right" Width="100px" CommitChanges="True" Decimals="2">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="KitRefNbr" TextAlign="Center" Width="100px" LinkCommand="viewPartialKit">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="KitStatus" TextAlign="Center" Width="100px">
									</px:PXGridColumn>
									<px:PXGridColumn DataField="CompletePartialButtonEnabled" Type="CheckBox"></px:PXGridColumn></Columns>
							</px:PXGridLevel>
						</Levels>
						<Mode InitNewRow="True" ></Mode>
						<AutoSize Enabled="True" MinHeight="150"></AutoSize>
						<ActionBar ActionsText="False">
							<CustomItems>
								<px:PXToolBarButton Text="Complete Partial" DependOnGrid="partCompGrid" StateColumn="CompletePartialButtonEnabled">
									<AutoCallBack Command="CompletePartial" Target="ds">
										<Behavior CommitChanges="True"></Behavior>
									</AutoCallBack>
								</px:PXToolBarButton>
							</CustomItems>
						</ActionBar>
					</px:PXGrid>
				</Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Costing / Analysis" Visible="True">
				<Template>
					<px:PXFormView ID="formJP" runat="server" DataSourceID="ds" Style="z-index: 100; left: 18px; top: 36px;" Width="100%" DataMember="CurrentDocument" CaptionVisible="False" SkinID="Transparent">
						<Template>
							<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="SM" GroupCaption="Planned"></px:PXLayoutRule>
							<px:PXNumberEdit ID="edjpPlannedLabor" runat="server" DataField="PlannedLabor" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXLayoutRule runat="server" StartColumn="False" LabelsWidth="SM" ControlSize="SM" GroupCaption="Costs"></px:PXLayoutRule>
							<px:PXNumberEdit ID="edjpplannedCostStock" runat="server" DataField="PlannedCostStock" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpPlannedCostLabor" runat="server" DataField="PlannedCostLabor" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpplannedCostNonStockNonLabor" runat="server" DataField="PlannedCostNonStockNonLabor" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXLayoutRule runat="server" ID="edjpEmptyLayoutRule1"></px:PXLayoutRule>
							<px:PXLabel runat="server" ID="edjpEmptyLabel1"></px:PXLabel>
							<px:PXNumberEdit ID="edjpplannedCost" runat="server" DataField="PlannedCost" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXLayoutRule runat="server" StartColumn="False" LabelsWidth="SM" ControlSize="SM" GroupCaption="Per Unit"></px:PXLayoutRule>
							<px:PXNumberEdit ID="edjplannedUnitCost" runat="server" DataField="PlannedUnitCost" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edfabQtyUnitCost" runat="server" DataField="FabQtyUnitCost" Enabled="false" Size="Empty"></px:PXNumberEdit> 
							<px:PXNumberEdit ID="edjpPlannedMarkup" runat="server" DataField="PlannedMarkup" Enabled="true" Size="Empty" CommitChanges="True"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpplannedPrice" runat="server" DataField="PlannedPrice" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXButton ID="recalculateOrderCost" runat="server" Text="Recalc Planned Costs" CommandName="RecalcPlannedCost" CommandSourceID="ds" AlignLeft="false"></px:PXButton>
							<px:PXLayoutRule StartColumn="True" runat="server" ID="edjpEmptyLayoutRule2"></px:PXLayoutRule>
							<px:PXLayoutRule runat="server" ID="CstPXLayoutRule4" Merge="False" LabelsWidth="SM" ControlSize="S"></px:PXLayoutRule>
							<px:PXTextEdit ID="edTranDesc" runat="server" DataField="WoLaborUnit"></px:PXTextEdit>
							<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="SM" GroupCaption="Actual"></px:PXLayoutRule>
							<px:PXNumberEdit ID="edjpActualLaborTime" runat="server" DataField="ActualLaborTime" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXLayoutRule runat="server" StartColumn="False" LabelsWidth="SM" ControlSize="SM" GroupCaption="Costs"></px:PXLayoutRule>
							<px:PXNumberEdit ID="edjpActualCostStock" runat="server" DataField="ActualCostStock" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpActualCostLabor" runat="server" DataField="ActualCostLabor" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpActualCostNonStockNonLabor" runat="server" DataField="ActualCostNonStockNonLabor" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpActualScrapCost" runat="server" DataField="ActualScrapCost" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpActualCost" runat="server" DataField="ActualCost" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXLabel runat="server" ID="FlxCstLabel22" ></px:PXLabel>
							
							<px:PXButton Width="90px" ID="batchNbr" runat="server" Text="Batch Nbr" CommandName="BatchNbr" CommandSourceID="ds" AlignLeft="false"></px:PXButton>
	
							<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="SM" GroupCaption="Variance"></px:PXLayoutRule>
							<px:PXNumberEdit ID="edjpVariableLaborTime" runat="server" DataField="VariableLaborTime" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXLayoutRule runat="server" StartColumn="False" LabelsWidth="SM" ControlSize="SM" GroupCaption="Costs"></px:PXLayoutRule>
							<px:PXNumberEdit ID="edjpVariableCostStock" runat="server" DataField="VariableCostStock" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpVariableCostLabor" runat="server" DataField="VariableCostLabor" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpVariableCostNonStockNonLabor" runat="server" DataField="VariableCostNonStockNonLabor" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpVariableScrapCost" runat="server" DataField="VariableScrapCost" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXNumberEdit ID="edjpVariableCost" runat="server" DataField="VariableCost" Enabled="false" Size="Empty"></px:PXNumberEdit>
							<px:PXLayoutRule runat="server" StartColumn="False" LabelsWidth="SM" ControlSize="SM" GroupCaption="Per Unit"></px:PXLayoutRule>
							<px:PXNumberEdit ID="edjpVariableUnitCost" runat="server" DataField="VariableUnitCost" Enabled="false" Size="Empty"></px:PXNumberEdit></Template>
					</px:PXFormView>
				</Template>
			</px:PXTabItem>
			<px:PXTabItem Visible="True" Text="Pricing">
				<Template>
					<px:PXFormView runat="server" ID="FlxCLPPricingFormView" DataMember="CurrentDocument">
						<Template>
							<px:PXLayoutRule runat="server" ID="FlxClpPXLayoutRule14" StartColumn="True" />
							<px:PXLayoutRule runat="server" ID="FlxClpPXLayoutRule15" StartGroup="True" GroupCaption="Costs (Reference)" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit19" DataField="PlannedCostStock" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit18" DataField="PlannedCostNonStockNonLabor" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit17" DataField="PlannedCostLabor" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit16" DataField="PlannedCost" Enabled="False" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit20" DataField="PlannedQty" Enabled="False" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit21" DataField="PlannedUnitCost" />
							<px:PXLayoutRule runat="server" ID="FlxClpPXLayoutRule13" StartColumn="True" />
							<px:PXLayoutRule runat="server" ID="FlxClpPXLayoutRule22" StartGroup="True" GroupCaption="Pricing" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit40" DataField="UsrClpPricnMaterials" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit41" DataField="UsrClpPricnNonStock" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit39" DataField="UsrClpPricnLabor" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit46" DataField="UsrClpPricnTotal" />
							<px:PXLabel runat="server" ID="FlxClpLabel48" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit47" DataField="UsrClpPricnPerUnit" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit32" DataField="UsrClpPricnCurUnitMarkup" />
							<px:PXButton runat="server" ID="priceToDoc" AlignLeft="True" Text="Update Source Document Price">
								<AutoCallBack Target="ds" Command="PriceToDoc" /></px:PXButton>
							<px:PXLayoutRule runat="server" ID="FlxClpPXLayoutRule37" StartColumn="True" />
							<px:PXLayoutRule runat="server" ID="FlxClpPXLayoutRule38" StartGroup="True" GroupCaption="Analysis" />
							<px:PXTextEdit runat="server" ID="FlxClpPXTextEdit33" DataField="UsrClpPricnCustomerPriceClassID" />
							<px:PXTextEdit runat="server" ID="FlxClpPXTextEdit36" DataField="UsrClpPricnPriceType" />
							<px:PXLabel runat="server" ID="FlxClpLabel42" />
							<px:PXLabel runat="server" ID="FlxClpLabel49" />
							<px:PXLabel runat="server" ID="FlxClpLabel43" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit34" DataField="UsrClpPricnDefaultMinPrice" />
							<px:PXNumberEdit runat="server" ID="FlxClpPXNumberEdit35" DataField="UsrClpPricnMinUnitMarkup" /></Template></px:PXFormView></Template></px:PXTabItem></Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150"></AutoSize>
		<CallbackCommands>
			<Refresh CommitChanges="True" PostData="Page"></Refresh>
			<Search CommitChanges="True" PostData="Page"></Search>
		</CallbackCommands>
	</px:PXTab>

	<px:PXSmartPanel ID="pnlCopyCompany" runat="server" CaptionVisible="True" Caption="Load Template" Style="position: static" LoadOnDemand="True" Key="TemplateFilter" AutoCallBack-Target="frmMyCommand" AutoCallBack-Command="Refresh" DesignView="Content">
		<px:PXFormView ID="frmMyCommand" runat="server" SkinID="Transparent" DataMember="TemplateFilter" DataSourceID="ds" EmailingGraph="">
			<Template>
				<px:PXLayoutRule runat="server" ControlSize="L" LabelsWidth="S" StartColumn="True" />
				<px:PXSelector ID="edMyField" runat="server" AutoRefresh="True" DataField="TemplateID" DataSourceID="ds" />
				<px:PXPanel ID="PXPanel1" runat="server" SkinID="Buttons">
					<px:PXButton ID="btnMyCommandOK" runat="server" DialogResult="OK" Text="OK">
						<AutoCallBack Command="Save" Target="frmMyCommand" />
					</px:PXButton>
					<px:PXButton ID="btnMyCommandCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
				</px:PXPanel>
			</Template>
		</px:PXFormView>
	</px:PXSmartPanel>

</asp:Content>