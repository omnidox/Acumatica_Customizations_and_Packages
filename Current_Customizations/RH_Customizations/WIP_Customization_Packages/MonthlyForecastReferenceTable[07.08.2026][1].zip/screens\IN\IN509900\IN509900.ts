
import { createCollection, createSingle, graphInfo, PXView, PXScreen, PXFieldState, gridConfig, PXFieldOptions, PXActionState, GridPreset } from "client-controls";

@graphInfo({
	graphType: "MonthlyForecastReferenceTable.MonthlyForecastMaint",
	primaryView: "MasterView",
})
export class IN509900 extends PXScreen {
	MasterView = createSingle(MasterViewClass);

	DetailsView = createCollection(DetailsViewClass);
}

export class MasterViewClass extends PXView {

}

@gridConfig({
	preset: GridPreset.Primary
})
export class DetailsViewClass extends PXView {

}